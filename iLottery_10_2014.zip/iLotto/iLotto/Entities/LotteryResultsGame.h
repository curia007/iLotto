//
//  MegaMillionsGame.h
//  SampleLotto
//
//  Created by Carmelo I. Uria on 5/3/13.
//  Copyright (c) 2013 Carmelo Uria Corporation. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface LotteryResultsGame : NSObject

@property (nonatomic, strong) NSDate *date;
@property (nonatomic, strong) NSString *name;
@property (nonatomic, strong) NSString *information;
@property (nonatomic, strong) NSSet *numbers;
@property (nonatomic, assign) NSInteger multipilier;

@end
