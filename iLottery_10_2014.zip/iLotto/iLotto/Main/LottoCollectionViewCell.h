//
//  LottoCollectionViewCell.h
//  iLotto
//
//  Created by Carmelo I. Uria on 8/24/13.
//  Copyright (c) 2013 Carmelo Uria Corporation. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LottoCollectionViewCell : UICollectionViewCell

@property (weak, nonatomic) IBOutlet UIImageView *imgeView;
@property (weak, nonatomic) IBOutlet UITextView *textView;

@end
