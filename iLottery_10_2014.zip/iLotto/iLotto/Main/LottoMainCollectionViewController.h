//
//  LottoMainCollectionViewController.h
//  iLotto
//
//  Created by Carmelo I. Uria on 8/8/13.
//  Copyright (c) 2013 Carmelo Uria Corporation. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LottoMainCollectionViewController : UICollectionViewController <UICollectionViewDataSource,UICollectionViewDelegateFlowLayout>

@end
