//
//  LottoMainViewController.m
//  iLotto
//
//  Created by Carmelo I. Uria on 12/22/13.
//  Copyright (c) 2013 Carmelo Uria Corporation. All rights reserved.
//

#import "LottoMainViewController.h"

#import <JATicker/JATicker.h>

#import "AppDelegate.h"
#import "Lottery.h"

#import "MegaMillionsTickerController.h"
#import "PowerballTickerController.h"
#import "PowerballProcessor.h"
#import "MegaMillionsProcessor.h"

#import "LotteryResultsGame.h"

@interface LottoMainViewController ()

@property (weak, nonatomic) IBOutlet JATickerView *megaMillionsTickerView;
@property (weak, nonatomic) IBOutlet JATickerView *powerballTickerView;

@property (strong, nonatomic) MegaMillionsTickerController *megaMillionsTickerController;
@property (strong, nonatomic) PowerballTickerController *powerballTickerController;

@property (strong, nonatomic) NSArray *results;

- (NSString *) stringWithDate:(NSDate *) date;

@end

@implementation LottoMainViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self)
    {
        // Custom initialization
    }
    
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    // Do any additional setup after loading the view.
    [[NSNotificationCenter defaultCenter] addObserverForName:LotteryResultsNotification object:self queue:[NSOperationQueue currentQueue] usingBlock:^(NSNotification *note) {
        
        NSLog(@"Test note");
    }];
    
    AppDelegate *appDelegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
    [[appDelegate feedReader] setDelegate:self];
    [[appDelegate feedReader] processResults];
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (NSString *) stringWithDate:(NSDate *) date
{
	NSAssert(date != nil, @"%s date cannot be nil", __PRETTY_FUNCTION__);
    
	NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
	[dateFormatter setDateFormat:@"MM/dd/yyyy"];
	
	NSString *dateString = [dateFormatter stringFromDate:date];
    
    return dateString;
}

#pragma mark -
#pragma mark - USlotteryFeedReaderDelegate methods

- (void) lotteryFeedReader:(USLotteryFeedReader *) reader completedWithError:(NSError *) error
{
    NSLog(@"%s  %@", __PRETTY_FUNCTION__, [error description]);
}

- (void) lotteryFeedReader:(USLotteryFeedReader *) reader completedWithResults:(NSArray *) results
{
    AppDelegate *appDelegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
    
    NSString *sound = @"money.mp3";
    NSMutableString *alertBody = [NSMutableString string];
    UILocalNotification *resultsNotification = [[UILocalNotification alloc] init];
    
    [resultsNotification setFireDate:[NSDate date]];
    
    [resultsNotification setSoundName:sound];
    [resultsNotification setAlertBody:alertBody];
    
    NSUInteger count = [[UIApplication sharedApplication] applicationIconBadgeNumber];
    count = count + [results count];
    
    [resultsNotification setApplicationIconBadgeNumber:count];
    
    
    [results enumerateObjectsUsingBlock:^(LotteryResultsGame *gameResults, NSUInteger idx, BOOL *stop) {
        NSLog(@"%s results name : %@ (%@)", __PRETTY_FUNCTION__, [gameResults name], [gameResults information]);
        
        if ([[gameResults name] compare:@"powerball" options:NSCaseInsensitiveSearch] == NSOrderedSame)
        {
            [[appDelegate powerballProcessor] processLatestLottoNumber:gameResults];
        }
        else if ([[gameResults name] compare:@"megamillions" options:NSCaseInsensitiveSearch] == NSOrderedSame)
        {
            [[appDelegate megaMillionsProcessor] processLatestLottoNumber:gameResults];
        }
        
        NSString *stringResults = [NSString stringWithFormat:@"%@ : %@\n\n%@", [gameResults name], [self stringWithDate:[gameResults date]], [gameResults information]];
        
        [alertBody appendFormat:@"%@/n/n", stringResults];
        
    }];
    
    _results = results;
    
    _megaMillionsTickerController = [[MegaMillionsTickerController alloc] initWithLotteryResults:[[self results] firstObject]];
    _powerballTickerController = [[PowerballTickerController alloc] initWithLotteryResults:[[self results] firstObject]];
    
    [[self megaMillionsTickerView] setDelegate:[self megaMillionsTickerController]];
    [[self powerballTickerView] setDelegate:[self powerballTickerController]];
    
    [[self megaMillionsTickerView] startTicker];
    [[self powerballTickerView] startTicker];

    // send notification
    NSNotificationCenter *defaultCenter = [NSNotificationCenter defaultCenter];
    [defaultCenter postNotificationName:LotteryResultsNotification object:results];
    
    [resultsNotification setAlertBody:alertBody];
    [[UIApplication sharedApplication] presentLocalNotificationNow:resultsNotification];
}

@end
