//
//  LottoMainCollectionViewController.m
//  iLotto
//
//  Created by Carmelo I. Uria on 8/8/13.
//  Copyright (c) 2013 Carmelo Uria Corporation. All rights reserved.
//

#import "LottoMainCollectionViewController.h"

#import "Lottery.h"

#define POWERBALL_INDEX 0
#define MEGAMILLIONS_INDEX 1

@interface LottoMainCollectionViewController ()

@end

@implementation LottoMainCollectionViewController

- (id) initWithNibName:(NSString *) nibNameOrNil bundle:(NSBundle *) nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self)
    {
        // Custom initialization
    }
    
    return self;
}

- (void) viewDidLoad
{
    [super viewDidLoad];
    
	// Do any additional setup after loading the view.
    [[NSNotificationCenter defaultCenter] addObserverForName:LotteryResultsNotification object:self queue:[NSOperationQueue currentQueue] usingBlock:^(NSNotification *note) {
        
        NSLog(@"Test note");
    }];
}

- (void) didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark -
#pragma mark - Collection View Data Source methods

- (NSInteger) collectionView:(UICollectionView *) collectionView numberOfItemsInSection:(NSInteger) section
{
    return 2;
}

// The cell that is returned must be retrieved from a call to - dequeueReusableCellWithReuseIdentifier:forIndexPath:
- (UICollectionViewCell *) collectionView:(UICollectionView *) collectionView cellForItemAtIndexPath:(NSIndexPath *) indexPath
{
    UICollectionViewCell *cell = nil;
    
    if (indexPath.row == POWERBALL_INDEX)
    {
        cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"PowerballIdentifier" forIndexPath:indexPath];
    }
    else if (indexPath.row == MEGAMILLIONS_INDEX)
    {
        cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"MegaMillionsIdentifier" forIndexPath:indexPath];
    }

    return cell;
}

#pragma mark -
#pragma mark – UICollectionViewDelegateFlowLayout Methods


- (CGSize) collectionView:(UICollectionView *) collectionView layout:(UICollectionViewLayout*) collectionViewLayout
{
    return CGSizeMake(0.0f, 0.0f);
}

- (UIEdgeInsets) collectionView:
(UICollectionView *) collectionView layout:(UICollectionViewLayout*) collectionViewLayout insetForSectionAtIndex:(NSInteger) section
{
    return UIEdgeInsetsMake(0.0f, 0.0f, 0.0f, 0.0f);
}

@end
