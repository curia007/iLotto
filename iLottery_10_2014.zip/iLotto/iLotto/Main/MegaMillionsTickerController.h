//
//  MegaMillionsTickerController.h
//  iLotto
//
//  Created by Carmelo I. Uria on 12/22/13.
//  Copyright (c) 2013 Carmelo Uria Corporation. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <JATicker/JATicker.h>

#import "LotteryResultsGame.h"

@interface MegaMillionsTickerController : NSObject <JATickerViewDelegate>

- (id) initWithLotteryResults:(LotteryResultsGame *) lotteryResults;

@end
