//
//  LottoMainAudioViewController.h
//  iLotto
//
//  Created by Carmelo I. Uria on 12/29/13.
//  Copyright (c) 2013 Carmelo Uria Corporation. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <SpeechKit/SpeechKit.h>

#import "EZMicrophone.h"

@interface LottoMainAudioViewController : UIViewController <EZMicrophoneDelegate, SpeechKitDelegate, SKRecognizerDelegate>

@end
