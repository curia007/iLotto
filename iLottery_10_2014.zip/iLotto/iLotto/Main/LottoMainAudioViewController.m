//
//  LottoMainAudioViewController.m
//  iLotto
//
//  Created by Carmelo I. Uria on 12/29/13.
//  Copyright (c) 2013 Carmelo Uria Corporation. All rights reserved.
//

#import "LottoMainAudioViewController.h"

#import "AppDelegate.h"

#import "PowerballProcessor.h"
#import "MegaMillionsProcessor.h"
#import "LottoRuleEngine.h"

#import "EZAudioPlot.h"
#import "EZAudio.h"

#import "VoiceRecognizer.h"

@interface LottoMainAudioViewController ()

@property (weak, nonatomic) IBOutlet EZAudioPlot *audioPlot;
@property (strong, nonatomic) EZMicrophone *microphone;
@property (nonatomic, strong) VoiceRecognizer *voiceRecognizer;

- (void) processCommandResultsWithRecognition:(SKRecognition *) results;

@end

@implementation LottoMainAudioViewController

- (id) initWithNibName:(NSString *) nibNameOrNil bundle:(NSBundle *) nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self)
    {
        // Custom initialization
    }
    return self;
}

- (void) viewDidLoad
{
    [super viewDidLoad];
    
    // Do any additional setup after loading the view.
    [SpeechKit setupWithID:@"NMDPTRIAL_Carmelo_Uria_Corporation_curia00720110415154408"
                      host:@"sandbox.nmdp.nuancemobility.net"
                      port:443
                    useSSL:NO
                  delegate:self];

    
    // Plot type
    self.audioPlot.plotType        = EZPlotTypeBuffer;
    self.audioPlot.backgroundColor = [UIColor whiteColor];
 
    // create VoiceRecognizer
    _voiceRecognizer = [[VoiceRecognizer alloc] initWithRecognizerDelegate:self locale:[NSLocale currentLocale]];
    [[self voiceRecognizer] record];
    
    /*
     Start the microphone
     */
    self.microphone = [EZMicrophone microphoneWithDelegate:self];
    [self.microphone startFetchingAudio];
   
    //AppDelegate *appDelegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
    //PowerballProcessor *powerballProcessor = [appDelegate powerballProcessor];
    //[powerballProcessor retrievePowerballWinnersWithCount:10 whiteBallGenerationType:kHighNumberOfHits powerballGenerationType:kHighNumberOfHits];
}

- (void) viewDidAppear:(BOOL) animated
{
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/


- (void) processCommandResultsWithRecognition:(SKRecognition *) results
{

    NSString *suggestion = [results suggestion];
    NSArray *possibleStatements =[results results];
    
    LottoRuleEngine *lottoRuleEngine = [[LottoRuleEngine alloc] init];
    
    if (suggestion != nil)
    {
        NSLog(@"strong suggestion here:  %@", suggestion);
        NSArray *components = [suggestion componentsSeparatedByCharactersInSet:[NSCharacterSet whitespaceCharacterSet]];
        [lottoRuleEngine analizeWithComponents:components];
    }
    
    if (possibleStatements != nil)
    {
        [possibleStatements enumerateObjectsUsingBlock:^(id obj, NSUInteger idx, BOOL *stop) {
            // What to put here?  seperate line and process each statement
            NSArray *components = [obj componentsSeparatedByCharactersInSet:[NSCharacterSet whitespaceCharacterSet]];
            [lottoRuleEngine analizeWithComponents:components];
#ifdef DEBUG
            NSLog(@"<%s>:  components : %@", __PRETTY_FUNCTION__, components);
#endif
        }];
    }
}

#pragma mark -
#pragma mark SpeechKitDelegate methods

- (void) destroyed
{
    NSLog(@"SpeechKitDelegate destroyed");
}

#pragma mark -
#pragma mark - EZMicrophoneDelegate
#warning Thread Safety

// Note that any callback that provides streamed audio data (like streaming microphone input) happens on a separate audio thread that should not be blocked. When we feed audio data into any of the UI components we need to explicity create a GCD block on the main thread to properly get the UI to work.
- (void) microphone:(EZMicrophone *) microphone hasAudioReceived:(float **) buffer withBufferSize:(UInt32) bufferSize
withNumberOfChannels:(UInt32) numberOfChannels
{
    // Getting audio data as an array of float buffer arrays. What does that mean? Because the audio is coming in as a stereo signal the data is split into a left and right channel. So buffer[0] corresponds to the float* data for the left channel while buffer[1] corresponds to the float* data for the right channel.
    
    // See the Thread Safety warning above, but in a nutshell these callbacks happen on a separate audio thread. We wrap any UI updating in a GCD block on the main thread to avoid blocking that audio flow.
    dispatch_async(dispatch_get_main_queue(),^{
        // All the audio plot needs is the buffer data (float*) and the size. Internally the audio plot will handle all the drawing related code, history management, and freeing its own resources. Hence, one badass line of code gets you a pretty plot :)
        [self.audioPlot updateBuffer:buffer[0] withBufferSize:bufferSize];
    });
}

- (void) microphone:(EZMicrophone *) microphone hasAudioStreamBasicDescription:(AudioStreamBasicDescription)audioStreamBasicDescription
{
    // The AudioStreamBasicDescription of the microphone stream. This is useful when configuring the EZRecorder or telling another component what audio format type to expect.
    // Here's a print function to allow you to inspect it a little easier
    [EZAudio printASBD:audioStreamBasicDescription];
}

- (void) microphone:(EZMicrophone *) microphone hasBufferList:(AudioBufferList *) bufferList withBufferSize:(UInt32)bufferSize withNumberOfChannels:(UInt32) numberOfChannels
{
    // Getting audio data as a buffer list that can be directly fed into the EZRecorder or EZOutput. Say whattt...
}

#pragma mark -
#pragma mark SKRecognizerDelegate methods

- (void) recognizerDidBeginRecording:(SKRecognizer *) recognizer
{
    NSLog(@"Recording started.");
}

- (void) recognizerDidFinishRecording:(SKRecognizer *) recognizer
{
    NSLog(@"Recording finished.");
    
}

- (void) recognizer:(SKRecognizer *) recognizer didFinishWithResults:(SKRecognition *) results
{
    
    [self processCommandResultsWithRecognition:results];
    
    NSLog(@"Got results:  with sugguestion: %@ and results: %@", [results suggestion], [results results] );
    NSLog(@"Session id [%@].", [SpeechKit sessionID]); // for debugging purpose: printing out the speechkit session id
    
}

- (void) recognizer:(SKRecognizer *) recognizer didFinishWithError:(NSError *)error suggestion:(NSString *) suggestion
{
    if (error != nil)
    {
        NSLog(@"recognizer error: %@", [error description]);
        NSLog(@"Session id [%@].", [SpeechKit sessionID]); // for debugging purpose: printing out the speechkit session id
        return;
    }
}

@end
