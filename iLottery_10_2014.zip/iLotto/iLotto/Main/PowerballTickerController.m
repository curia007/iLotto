//
//  PowerballTickerController.m
//  iLotto
//
//  Created by Carmelo I. Uria on 12/22/13.
//  Copyright (c) 2013 Carmelo Uria Corporation. All rights reserved.
//

#import "PowerballTickerController.h"

#import "LotteryResultsGame.h"

@interface PowerballTickerController ()

@property (strong, nonatomic) LotteryResultsGame *lotteryResults;

@end

@implementation PowerballTickerController

- (id) initWithLotteryResults:(LotteryResultsGame *) lotteryResults
{
    self = [super init];
    
    if (self != nil)
    {
        _lotteryResults = lotteryResults;
    }
    
    
    return self;
}

/**
 * Polls for more ticker data to be appended to the end of the ticker.
 **/
-(NSString *) tickerView:(JATickerView *) tickerView tickerDataAtEnd:(NSUInteger) currentLength
{
    NSLog(@"tickerDataAtEnd currentLength=%d", currentLength);
    if (currentLength == 0)
    {
        return @"Waiting for Powerball Information";
    }
    else
    {
        if ([self lotteryResults] != nil)
        {
            return [[self lotteryResults] information];
        }
        else
        {
            return @"";
        }
    }
    
    return @"";
}

/**
 * The image to use to render an "on" lightbulb at the given cell (X, Y), relative to the top left
 * of where the ticker is shown. If this method is not implemented, uses a default image.
 * Images for all dots must be the exact same, square, dimensions, otherwise the image will not be used.
 **/
//-(UIImage *) tickerView:(JATickerView *) tickerView imageForLightOnAtX:(NSUInteger) x andY:(NSUInteger) y
//{
//    return nil;
//}

/**
 * The image to use to render an "off" lightbulb at the given cell (X,Y), relative to the top left
 * of where the ticker is shown. If this method is not implemented, uses a default image.
 * Images for all dots must be the exact same, square, dimensions, otherwise the image will not be used.
 **/
//-(UIImage *) tickerView:(JATickerView *) tickerView imageForLightOffAtX:(NSUInteger) x andY:(NSUInteger) y
//{
//    return nil;
//}

/**
 * When the ticker encounters a character that it does not know how to digitize,
 * it polls the delegate to see if the client can supply a digitized definition.
 * A digitized definition indicates which lights to light up on the ticker to display
 * the character. Should return nil if the delegate cannot provide a definition for this character.
 **/
-(JATickerChar *) tickerView:(JATickerView *) tickerView definitionForCharacter:(unichar) c
{
    NSLog(@"definitionForCharacter called for %c", c);
    if ( c == '<' )
    {
        return [[JATickerChar alloc] initWithASCIIString:
                [NSString stringWithFormat:@"%@%@%@%@%@%@",
                 @"   ..",
                 @" ..  ",
                 @".    ",
                 @".    ",
                 @" ..  ",
                 @"   .."]];
    }
    else if ( c == '>' )
    {
        return [[JATickerChar alloc] initWithASCIIString:
                [NSString stringWithFormat:@"%@%@%@%@%@%@",
                 @"..   ",
                 @"  .. ",
                 @"    .",
                 @"    .",
                 @"  .. ",
                 @"..   "]];
    }
    else
    {
        return nil;
    }
}

/**
 * Optional delegate method that calls back to the client once the ticker has
 * ticked past a certain number of characters. Can be used to stop the ticker
 * once it has reached a certain point.
 **/
-(void) tickerView:(JATickerView *) tickerView tickerReachedPosition:(NSUInteger) pos
{
    
}

@end
