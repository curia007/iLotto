//
//  LottoProcessor.h
//  iLotto
//
//  Created by Carmelo I. Uria on 7/27/13.
//  Copyright (c) 2013 Carmelo Uria Corporation. All rights reserved.
//

typedef enum {
    kPowerballLottoType,
    kMegaMillionsLottoType
} LottoType;

typedef enum {
    kHighNumberOfHits,
    kLowNumberOfHits,
    kMixNumberOfHits
} LottoGenerationType;

@class ModelManager;
@class LotteryResultsGame;


@interface LottoProcessor : NSObject

@property (nonatomic, strong, readonly) ModelManager *modelManager;
@property (nonatomic, strong, readonly) NSOperationQueue *queue;

- (void) generateWinningTicketsWithLottoType:(LottoType)lottoType count:(NSInteger) count generationType:(LottoGenerationType) generationType moneyBallGenerationType:(LottoGenerationType) moneyBallGenerationType;

- (void) processLatestLottoNumber:(LotteryResultsGame *) gameResults;

@end
