//
//  PowerballIncrementalStore.m
//  SampleLotto
//
//  Created by Carmelo I. Uria on 5/19/13.
//  Copyright (c) 2013 Carmelo Uria Corporation. All rights reserved.
//

#import "PowerballIncrementalStore.h"

@implementation PowerballIncrementalStore

+ (void) initialize
{
    [NSPersistentStoreCoordinator registerStoreClass:self forStoreType:[self type]];
}

+ (NSString *) type
{
    return NSStringFromClass(self);
}

- (BOOL) loadMetadata:(NSError **) error
{
    // TODO: find out how to generate the UUID? Does it matter?
    NSString* uuid = [[NSProcessInfo processInfo] globallyUniqueString];
    [self setMetadata:[NSDictionary dictionaryWithObjectsAndKeys:@"PowerballIncrementalStore", NSStoreTypeKey, uuid, NSStoreUUIDKey, nil]];

    return YES;
}

- (id) executeRequest:(NSPersistentStoreRequest *) request withContext:(NSManagedObjectContext *) context error:(NSError **) error
{
    
    return nil;
}

- (NSIncrementalStoreNode *) newValuesForObjectWithID:(NSManagedObjectID *) objectID withContext:(NSManagedObjectContext *) context error:(NSError **) error
{
    return nil;    
}

- (id) newValueForRelationship:(NSRelationshipDescription *) relationship forObjectWithID:(NSManagedObjectID *) objectID withContext:(NSManagedObjectContext *) context error:(NSError **) error
{
    return nil;
}

- (NSArray *) obtainPermanentIDsForObjects:(NSArray *) array error:(NSError **) error
{
    return nil;    
}

@end
