//
//  PowerballProcessor.m
//  SampleLotto
//
//  Created by Carmelo I. Uria on 5/19/13.
//  Copyright (c) 2013 Carmelo Uria Corporation. All rights reserved.
//
//  http://www.powerball.com/powerball/winnums-text.txt

#import "PowerballProcessor.h"
#import "ModelManager.h"

#import "Powerball.h"
#import "HitFrequency.h"

#import "LotteryResultsGame.h"

NSString* const PBCompletedPowerballProcessor = @"PowerballProcessorCompleted";

#define POWERBALL_NUMBERS_URL_STRING @"http://www.powerball.com/powerball/winnums-text.txt"

@interface PowerballProcessor ()

@property (nonatomic, strong) ModelManager *modelManager;
@property (nonatomic, strong) NSOperationQueue *queue;

- (void) processGame:(NSString *) gameInformation;

@end

@implementation PowerballProcessor

- (void) processLottoNumbers
{
    if ([self hasPowerballNumbers] == YES)
    {
        return;
    }

    NSURL *URL = [NSURL URLWithString:POWERBALL_NUMBERS_URL_STRING];
    NSURLRequest *request = [NSURLRequest requestWithURL:URL];
    [NSURLConnection sendAsynchronousRequest:request queue:[self queue] completionHandler:^(NSURLResponse *response, NSData *data, NSError *error)
     {
         NSString *string = [NSString stringWithUTF8String:[data bytes]];
         
         NSArray *lines = [string componentsSeparatedByCharactersInSet:[NSCharacterSet newlineCharacterSet]];
         
         if ([lines count] > 0)
         {
             NSMutableArray *array = [NSMutableArray arrayWithArray:lines];
             [array removeObjectAtIndex:0];
             lines = [NSArray arrayWithArray:array];
             array = nil;
             
             [lines enumerateObjectsUsingBlock:^(NSString *line, NSUInteger idx, BOOL *stop) {
                 [self processGame:line];
             }];
             
             NSMutableDictionary *userInformation = [NSMutableDictionary dictionaryWithCapacity:1];
             [userInformation setObject:self forKey:@"kPowerballProcessor"];
             
             [[NSNotificationCenter defaultCenter] postNotificationName:PBCompletedPowerballProcessor object:nil userInfo:userInformation];
             
         }
     }];
}

- (BOOL) hasPowerballNumbers
{
    NSManagedObjectModel *model = [[self modelManager] managedObjectModel];
    NSFetchRequest *fetchRequest = [model fetchRequestTemplateForName:@"PowerballFetchRequest"];
    
    NSError *error = nil;
    
    NSArray *gameResults = [[[self modelManager] managedObjectContext] executeFetchRequest:fetchRequest error:&error];
    
    if ([gameResults count] > 0)
    {
        return YES;
    }
    
    return NO;
}

- (void) processGame:(NSString *) gameInformation
{
    if ((gameInformation == nil) | ([gameInformation length] == 0))
    {
        return;
    }
    
    NSLog(@"%s: game information : %@", __PRETTY_FUNCTION__,gameInformation);
    NSArray *elements = [gameInformation componentsSeparatedByCharactersInSet:[NSCharacterSet whitespaceCharacterSet]];

    NSMutableArray *items = [NSMutableArray arrayWithCapacity:1];
    [elements enumerateObjectsUsingBlock:^(NSString *element, NSUInteger idx, BOOL *stop) {
        if ([element length]!= 0)
        {
            [items addObject:element];
        }
    }];
    
    NSString *date = [items objectAtIndex:0];
    
    BOOL isPowerballGameExist = [[self modelManager] isPowerballInformationExistsWithDate:date];
    
    if (isPowerballGameExist == YES)
    {
        return;
    }
   
    Powerball *powerballEntity = (Powerball *)[NSEntityDescription insertNewObjectForEntityForName:@"Powerball" inManagedObjectContext:[[self modelManager] managedObjectContext]];
    
    NSError *error = nil;
    
    [powerballEntity setDate:date];
    
    [powerballEntity setWb1:[NSNumber numberWithInteger:[[items objectAtIndex:1] integerValue]]];
    [powerballEntity setWb2:[NSNumber numberWithInteger:[[items objectAtIndex:2] integerValue]]];
    [powerballEntity setWb3:[NSNumber numberWithInteger:[[items objectAtIndex:3] integerValue]]];
    [powerballEntity setWb4:[NSNumber numberWithInteger:[[items objectAtIndex:4] integerValue]]];
    [powerballEntity setWb5:[NSNumber numberWithInteger:[[items objectAtIndex:5] integerValue]]];
    [powerballEntity setPb:[NSNumber numberWithInteger:[[items objectAtIndex:6] integerValue]]];
    
    if ([items count] == 8)
    {
        [powerballEntity setPp:[NSNumber numberWithInteger:[[items objectAtIndex:7] integerValue]]];
    }
    
    [[[self modelManager] managedObjectContext] save:&error];
    
    [[self modelManager] addFrequencyWithNumber:[[items objectAtIndex:1] integerValue] moneyBall:NO lottoType:@"powerball"];
    [[self modelManager] addFrequencyWithNumber:[[items objectAtIndex:2] integerValue] moneyBall:NO lottoType:@"powerball"];
    [[self modelManager] addFrequencyWithNumber:[[items objectAtIndex:3] integerValue] moneyBall:NO lottoType:@"powerball"];
    [[self modelManager] addFrequencyWithNumber:[[items objectAtIndex:4] integerValue] moneyBall:NO lottoType:@"powerball"];
    [[self modelManager] addFrequencyWithNumber:[[items objectAtIndex:5] integerValue] moneyBall:NO lottoType:@"powerball"];
    [[self modelManager] addFrequencyWithNumber:[[items objectAtIndex:6] integerValue] moneyBall:YES lottoType:@"powerball"];

}

- (void) retrievePowerballWinnersWithCount:(NSInteger) count whiteBallGenerationType:(LottoGenerationType) generationType powerballGenerationType:(LottoGenerationType) powerballGenerationType
{

    [self generateWinningTicketsWithLottoType:kPowerballLottoType count:count generationType:generationType moneyBallGenerationType:powerballGenerationType];
}

@end
