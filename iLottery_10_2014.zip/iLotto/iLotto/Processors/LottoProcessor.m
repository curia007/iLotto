//
//  LottoProcessor.m
//  iLotto
//
//  Created by Carmelo I. Uria on 7/27/13.
//  Copyright (c) 2013 Carmelo Uria Corporation. All rights reserved.
//

#import "LottoProcessor.h"

#import "ModelManager.h"
#import "FutureTicket.h"
#import "HitFrequency.h"

#import "WinningTicket.h"

#import "LotteryResultsGame.h"

@interface LottoProcessor ()

- (NSArray *) retrievePowerballPastNumbersWithGenerationType:(LottoGenerationType) generationType;
- (NSArray *) retrieveMegaMillionsPastNumbersWithGenerationType:(LottoGenerationType) generationType;
- (NSArray *) retrievePowerballMoneyballPastNumbersWithGenerationType:(LottoGenerationType) generationType;
- (NSArray *) retrieveMegaMillionslMoneyballPastNumbersWithGenerationType:(LottoGenerationType) generationType;
- (void) generateFutureTicketsWithLottoType:(LottoType) lottoType whiteballs:(NSArray *) whiteballs moneyballs:(NSArray *) moneyballs count:(NSInteger) count;

- (void) createTicketWithLottoType:(LottoType) lottoType date:(NSString *) date whiteNumbers:(NSArray *) whiteNumbers moneyball:(NSInteger) moneyball;

- (NSString *) nextLottoDateWithLottoType:(LottoType) lottoType;

@end

@implementation LottoProcessor

- (id) init
{
    if ([self queue] == nil)
    {
        _queue = [NSOperationQueue currentQueue];
    }
    
    if ([self modelManager] == nil)
    {
        _modelManager = [[ModelManager alloc] init];
    }

    return self;
}

- (void) generateWinningTicketsWithLottoType:(LottoType)lottoType count:(NSInteger) count generationType:(LottoGenerationType) generationType moneyBallGenerationType:(LottoGenerationType) moneyBallGenerationType
{
    
    if (lottoType == kPowerballLottoType)
    {
        NSArray *numbers = [self retrievePowerballPastNumbersWithGenerationType:generationType];
        NSArray *moneyballs = [self retrievePowerballMoneyballPastNumbersWithGenerationType:generationType];
        
        // create future tickets
        [self generateFutureTicketsWithLottoType:lottoType whiteballs:numbers moneyballs:moneyballs count:count];
    }
    else if (lottoType == kMegaMillionsLottoType)
    {
        NSArray *numbers = [self retrieveMegaMillionsPastNumbersWithGenerationType:generationType];
        NSArray *moneyballs = [self retrieveMegaMillionsPastNumbersWithGenerationType:generationType];
        
        // create future tickets
        [self generateFutureTicketsWithLottoType:lottoType whiteballs:numbers moneyballs:moneyballs count:count];

    }
    
}

- (void) processLatestLottoNumber:(LotteryResultsGame *) gameResults
{
    NSAssert(gameResults != nil, @"%s gameResults cannot be nil", __PRETTY_FUNCTION__);
    
#ifdef DEBUG
    NSLog(@"games results:  <date: %@> <numbers: %@>", [gameResults date], [gameResults numbers]);
#endif
    
    [[self modelManager] processWithLotteryResultsGame:gameResults];
}

- (NSArray *) retrievePowerballPastNumbersWithGenerationType:(LottoGenerationType) generationType
{

    if (generationType == kLowNumberOfHits)
    {
        NSSortDescriptor *sortDescriptor = [[NSSortDescriptor alloc] initWithKey:@"hitCount" ascending:YES];
        return [[self modelManager] retrieveFrequencyWithSortDescriptor:sortDescriptor lottoType:kPowerballLottoType];
    }
    else if (generationType == kHighNumberOfHits)
    {
        NSSortDescriptor *sortDescriptor = [[NSSortDescriptor alloc] initWithKey:@"hitCount" ascending:NO];
        return [[self modelManager] retrieveFrequencyWithSortDescriptor:sortDescriptor lottoType:kPowerballLottoType];
    }
    else if (generationType == kMixNumberOfHits)
    {
        
    }
    
    return nil;
}

- (NSArray *) retrieveMegaMillionsPastNumbersWithGenerationType:(LottoGenerationType) generationType
{
    NSError *error = nil;
    
    NSManagedObjectContext *managedObjectContext = [[self modelManager] managedObjectContext];

    NSFetchRequest *fetchRequest = [NSFetchRequest fetchRequestWithEntityName:@"HitFrequency"];
    NSPredicate *predicate = [NSPredicate predicateWithFormat:@"type == \"megamillions\""];
    
    if (generationType == kLowNumberOfHits)
    {
        NSSortDescriptor *sortDescriptor = [[NSSortDescriptor alloc] initWithKey:@"hitCount" ascending:YES];
        
        NSArray *sortDescriptors = [NSArray arrayWithObject:sortDescriptor];
        [fetchRequest setSortDescriptors:sortDescriptors];
        NSArray *entries = [managedObjectContext executeFetchRequest:fetchRequest error:&error];
        
        if (error != nil)
        {
            NSLog(@"error:  %@", error);
        }
        
        return entries;
    }
    else if (generationType == kHighNumberOfHits)
    {
        NSSortDescriptor *sortDescriptor = [[NSSortDescriptor alloc] initWithKey:@"hitCount" ascending:NO];
        
        NSArray *sortDescriptors = [NSArray arrayWithObject:sortDescriptor];
        [fetchRequest setSortDescriptors:sortDescriptors];
        NSArray *entries = [managedObjectContext executeFetchRequest:fetchRequest error:&error];
        
        if (error != nil)
        {
            NSLog(@"error:  %@", error);
        }
        
        return entries;
    }
    else if (generationType == kMixNumberOfHits)
    {
        
    }

    return nil;
}

- (NSArray *) retrievePowerballMoneyballPastNumbersWithGenerationType:(LottoGenerationType) generationType
{
    
    if (generationType == kLowNumberOfHits)
    {
        NSSortDescriptor *sortDescriptor = [[NSSortDescriptor alloc] initWithKey:@"moneyCount" ascending:YES];
        NSArray *hitFrequencies = [[self modelManager] retrieveFrequencyWithSortDescriptor:sortDescriptor lottoType:kPowerballLottoType];
       
        return hitFrequencies;
    }
    else if (generationType == kHighNumberOfHits)
    {
        NSSortDescriptor *sortDescriptor = [[NSSortDescriptor alloc] initWithKey:@"moneyCount" ascending:NO];
        NSArray *hitFrequencies = [[self modelManager] retrieveFrequencyWithSortDescriptor:sortDescriptor lottoType:kPowerballLottoType];
        
        return hitFrequencies;
    }

    return nil;
}

- (NSArray *) retrieveMegaMillionslMoneyballPastNumbersWithGenerationType:(LottoGenerationType) generationType;
{
    if (generationType == kLowNumberOfHits)
    {
        NSSortDescriptor *sortDescriptor = [[NSSortDescriptor alloc] initWithKey:@"moneyCount" ascending:YES];
        NSArray *hitFrequencies = [[self modelManager] retrieveFrequencyWithSortDescriptor:sortDescriptor lottoType:kMegaMillionsLottoType];
        
        return hitFrequencies;
    }
    else if (generationType == kHighNumberOfHits)
    {
        NSSortDescriptor *sortDescriptor = [[NSSortDescriptor alloc] initWithKey:@"moneyCount" ascending:NO];
        NSArray *hitFrequencies = [[self modelManager] retrieveFrequencyWithSortDescriptor:sortDescriptor lottoType:kMegaMillionsLottoType];
        
        return hitFrequencies;
    }

    return nil;
}

- (void) generateFutureTicketsWithLottoType:(LottoType) lottoType whiteballs:(NSArray *) whiteballs moneyballs:(NSArray *) moneyballs count:(NSInteger) count
{
    NSAssert([whiteballs count] > 0, @"%s:  whiteball count is zero", __PRETTY_FUNCTION__);
    NSAssert(moneyballs != nil, @"%s:  moneyball array is nil", __PRETTY_FUNCTION__);
    NSAssert([moneyballs count] > 0, @"%s:  moneyball count is zero", __PRETTY_FUNCTION__);
    
    if ((whiteballs == nil) ||([whiteballs count] == 0))
    {
        NSLog(@"%s:  whiteballs either empty or zero count", __PRETTY_FUNCTION__);
        return;
    }
    
    if ((whiteballs == nil) ||([whiteballs count] == 0))
    {
        NSLog(@"%s:  moneyballs either empty or zero count", __PRETTY_FUNCTION__);
        return;
    }
    
    
    NSUInteger whiteCount = 0;
    NSUInteger moneyCount = 0;
    
    NSInteger moneyball = 0;
    
    NSMutableArray *tickets = [NSMutableArray arrayWithCapacity:count];
    
    // check count against array counts
    if (count > [whiteballs count])
    {
        whiteCount = [whiteballs count];
    }
    else
    {
        whiteCount = count;
    }
    
    if (count > [moneyballs count])
    {
        moneyCount = [moneyballs count];
    }
    else
    {
        moneyCount = count;
    }

    for (NSUInteger gameIndex = 0; gameIndex < count; gameIndex++)
    {
        // create future game
        NSString *date = [self nextLottoDateWithLottoType:lottoType];
        NSMutableArray *whiteNumbers = [NSMutableArray arrayWithCapacity:6];
        
        for (NSUInteger index = 0; index < 5; index++)
        {
            int selectedIndex = arc4random() % whiteCount;
            [whiteNumbers addObject:[whiteballs objectAtIndex:selectedIndex]];
        }
        
        int moneyballIndex = arc4random() % moneyCount;
        
        HitFrequency *hitFrequency = [moneyballs objectAtIndex:moneyballIndex];
        
        moneyball = [[hitFrequency lottoNumber] integerValue];
        
        WinningTicket *winningTicket = [[WinningTicket alloc] initWithLottoType:lottoType date:date whiteNumbers:whiteNumbers moneyball:moneyball];
        [tickets addObject:winningTicket];
        
    }

    [[self modelManager] insertFutureTicketWithWinningTickets:tickets];
}

- (void) createTicketWithLottoType:(LottoType) lottoType date:(NSString *) date whiteNumbers:(NSArray *) whiteNumbers moneyball:(NSInteger) moneyball
{
    // check if future game exists
    NSArray *tickets = [[self modelManager] retrieveFutureTicketsWithDate:date];
    
    if ((tickets == nil) || ([tickets count] == 0))
    {
//        FutureGame *futureGame =(FutureGame *)[NSEntityDescription insertNewObjectForEntityForName:@"FutureGame" inManagedObjectContext:[self managedObjectContext]];
//        
//        if (lottoType == kMegaMillionsLottoType)
//        {
//            [futureGame setType:@"megamillions"];
//        }
//        else if (lottoType == kPowerballLottoType)
//        {
//            [futureGame setType:@"powerball"];
//        }
//        [futureGame setDate:date];

        // insert new ticket
        [[self modelManager] insertFutureTicketWithLottoType:lottoType date:date numbers:whiteNumbers moneyball:moneyball];
    }
    else
    {
        // update ticket
        [[self modelManager] updateFutureTicketWithLottoType:lottoType date:date numbers:whiteNumbers moneyball:moneyball];
    }
}

- (NSString *) nextLottoDateWithLottoType:(LottoType) lottoType
{
    
	NSDate *lotteryDate = nil;
	
	NSCalendar *calendar = [[NSCalendar alloc] initWithCalendarIdentifier:NSGregorianCalendar];
	NSDate *date = [NSDate date];
	
	//[components release];
	
	NSDateComponents *components = [calendar components:NSWeekdayCalendarUnit fromDate:date];
	
	int weekday = [components weekday];
	
	NSInteger diff = 0;
	
	// check for lottery type
	// lotteryType = 0 : MegaMillions
	
	if(lottoType == kMegaMillionsLottoType)
	{
		// MegaMillions type
		NSInteger Tue = 3;
		NSInteger Fri = 6;
		
		// check for Tuesday
		if(weekday <= 3)
		{
			diff = Tue - weekday;
			[components setWeekday:diff];
			lotteryDate = [calendar dateByAddingComponents:components toDate:date options:0];
		}
		else
		{
			// Friday
			diff = Fri - weekday;
			[components setWeekday:diff];
			lotteryDate = [calendar dateByAddingComponents:components toDate:date options:0];
		}
	}
	else
	{
		// Powerball type
		NSInteger Wed = 4;
		NSInteger Sat = 7;
        
		// check for Wed
		if(weekday <= 4)
		{
			diff = Wed - weekday;
			[components setWeekday:diff];
			lotteryDate = [calendar dateByAddingComponents:components toDate:date options:0];
		}
		else
		{
			// Saturday
			diff = Sat - weekday;
			[components setWeekday:diff];
			lotteryDate = [calendar dateByAddingComponents:components toDate:date options:0];
		}
		
	}
    
	NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
	[dateFormatter setDateFormat:@"MM/dd/yyyy"];
	
	NSString *dateString = [dateFormatter stringFromDate:lotteryDate];
    
    return dateString;
}

@end
