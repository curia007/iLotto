//
//  MegaMillionsProcessor.m
//  SampleLotto
//
//  Created by Carmelo I. Uria on 6/28/13.
//  Copyright (c) 2013 Carmelo Uria Corporation. All rights reserved.
//

#import "MegaMillionsProcessor.h"

#import "LotteryResultsGame.h"
#import "ModelManager.h"

#import "MegaMillions.h"

#define MEGAMILLIONS_NUMBERS_URL_STRING @"http://www.calottery.com/sitecore/content/Miscellaneous/download-numbers/?GameName=mega-millions"

NSString* const MMCompletedMegaMillionsProcessor = @"MegaMillionsProcessorCompleted";

@interface MegaMillionsProcessor ()

@end

@implementation MegaMillionsProcessor

- (void) processLottoNumbers
{
    if ([self hasMegaMillionsNumbers] == YES)
    {
        return;
    }
    
    NSURL *URL = [NSURL URLWithString:MEGAMILLIONS_NUMBERS_URL_STRING];
    NSURLRequest *request = [NSURLRequest requestWithURL:URL];
    
    [NSURLConnection sendAsynchronousRequest:request queue:[self queue] completionHandler:^(NSURLResponse *response, NSData *data, NSError *error)
     {
         NSString* string = nil;
         string = [[NSString alloc] initWithData:data encoding:NSASCIIStringEncoding];
         
         NSArray *lines = [string componentsSeparatedByCharactersInSet:[NSCharacterSet newlineCharacterSet]];
         NSMutableArray *array = [NSMutableArray arrayWithArray:lines];
         
         NSRange range;
         range.location = 0;
         range.length = 9;
         
         NSIndexSet *indexes = [NSIndexSet indexSetWithIndexesInRange:range];

         [array removeObjectsAtIndexes:indexes];
         
         lines = [NSArray arrayWithArray:array];
         array = nil;
         
         [lines enumerateObjectsUsingBlock:^(NSString *line, NSUInteger idx, BOOL *stop) {
             [self processGame:line];
         }];
         
         NSMutableDictionary *userInformation = [NSMutableDictionary dictionaryWithCapacity:1];
         [userInformation setObject:self forKey:@"kMegaMillionsProcessor"];
         
         [[NSNotificationCenter defaultCenter] postNotificationName:MMCompletedMegaMillionsProcessor object:nil userInfo:userInformation];
     }];
}

- (void) processGame:(NSString *) gameInformation
{
    if ((gameInformation == nil) | ([gameInformation length] == 0))
    {
        return;
    }
    
    NSLog(@"game information : %@", gameInformation);
    NSArray *elements = [gameInformation componentsSeparatedByCharactersInSet:[NSCharacterSet whitespaceCharacterSet]];
    
    NSMutableArray *items = [NSMutableArray arrayWithCapacity:1];
    [elements enumerateObjectsUsingBlock:^(NSString *element, NSUInteger idx, BOOL *stop) {
        if ([element length]!= 0)
        {
            [items addObject:element];
        }
    }];
    
    NSString *date = [NSString stringWithFormat:@"%@ %@%@ %@", [items objectAtIndex:1], [items objectAtIndex:2], [items objectAtIndex:3], [items objectAtIndex:4]];

    BOOL isMegaMillionsGameExist = [[self modelManager] isMegaMillionsInformationExistsWithDate:date];
    
    if (isMegaMillionsGameExist == YES)
    {
        return;
    }
    
    MegaMillions *megaMillionsEntity = (MegaMillions *)[NSEntityDescription insertNewObjectForEntityForName:@"MegaMillions" inManagedObjectContext:[[self modelManager] managedObjectContext]];
    
    NSError *error = nil;
    
    [megaMillionsEntity setLottoNumber:[NSNumber numberWithInt:[[items objectAtIndex:0] integerValue]]];
    [megaMillionsEntity setDate:date];
    
    [megaMillionsEntity setWb1:[NSNumber numberWithInteger:[[items objectAtIndex:5] integerValue]]];
    [megaMillionsEntity setWb2:[NSNumber numberWithInteger:[[items objectAtIndex:6] integerValue]]];
    [megaMillionsEntity setWb3:[NSNumber numberWithInteger:[[items objectAtIndex:7] integerValue]]];
    [megaMillionsEntity setWb4:[NSNumber numberWithInteger:[[items objectAtIndex:8] integerValue]]];
    [megaMillionsEntity setWb5:[NSNumber numberWithInteger:[[items objectAtIndex:9] integerValue]]];
    [megaMillionsEntity setMb:[NSNumber numberWithInteger:[[items objectAtIndex:10] integerValue]]];
    
    
    [[[self modelManager] managedObjectContext] save:&error];
    
    [[self modelManager] addFrequencyWithNumber:[[items objectAtIndex:5] integerValue] moneyBall:NO lottoType:@"megamillions"];
    [[self modelManager] addFrequencyWithNumber:[[items objectAtIndex:6] integerValue] moneyBall:NO lottoType:@"megamillions"];
    [[self modelManager] addFrequencyWithNumber:[[items objectAtIndex:7] integerValue] moneyBall:NO lottoType:@"megamillions"];
    [[self modelManager] addFrequencyWithNumber:[[items objectAtIndex:8] integerValue] moneyBall:NO lottoType:@"megamillions"];
    [[self modelManager] addFrequencyWithNumber:[[items objectAtIndex:9] integerValue] moneyBall:NO lottoType:@"megamillions"];
    [[self modelManager] addFrequencyWithNumber:[[items objectAtIndex:10] integerValue] moneyBall:YES lottoType:@"megamillions"];

}

- (BOOL) hasMegaMillionsNumbers
{
    NSManagedObjectModel *model = [[self modelManager] managedObjectModel];
    NSFetchRequest *fetchRequest = [model fetchRequestTemplateForName:@"MegaMillionsFetchRequest"];
    
    NSError *error = nil;
    
    NSArray *gameResults = [[[self modelManager] managedObjectContext] executeFetchRequest:fetchRequest error:&error];
    
    if ([gameResults count] > 0)
    {
        return YES;
    }
    
    return NO;
}

- (void) processLatestLottoNumber:(LotteryResultsGame *) game
{
    if ([self hasMegaMillionsNumbers] == NO)
    {
        [self processLottoNumbers];
    }
    else
    {
        if (game != nil)
        {
            NSLog(@"Add results to database");
        }
        else
        {
            NSError *error = nil;
//            NSManagedObjectContext *managedObjectContext = [self lottoWebServiceManagedObjectContext];
//            NSFetchRequest *fetchRequest = [[self managedObjectModel] fetchRequestTemplateForName:@"MegaMillionsFetchRequest"];
//            NSArray *results = [managedObjectContext executeFetchRequest:fetchRequest error:&error];
            NSLog(@"Test");
        }
    }
}

- (void) retrieveMegaMillionsWinnersWithCount:(NSInteger) count whiteBallGenerationType:(LottoGenerationType) generationType moneyBallGenerationType:(LottoGenerationType) moneyBallGenerationType
{
    
    [self generateWinningTicketsWithLottoType:kMegaMillionsLottoType count:count generationType:generationType moneyBallGenerationType:moneyBallGenerationType];
               
}

@end
