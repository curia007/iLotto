//
//  MegaMillionsProcessor.h
//  SampleLotto
//
//  Created by Carmelo I. Uria on 6/28/13.
//  Copyright (c) 2013 Carmelo Uria Corporation. All rights reserved.
//

#import "LottoProcessor.h"

extern NSString* const MMCompletedMegaMillionsProcessor;

@interface MegaMillionsProcessor : LottoProcessor

- (void) processLottoNumbers;
- (void) processLatestLottoNumber:(LotteryResultsGame *) game;

- (void) retrieveMegaMillionsWinnersWithCount:(NSInteger) count whiteBallGenerationType:(LottoGenerationType) generationType moneyBallGenerationType:(LottoGenerationType) moneyBallGenerationType;

@end
