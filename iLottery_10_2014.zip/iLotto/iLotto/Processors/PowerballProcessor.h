//
//  PowerballProcessor.h
//  SampleLotto
//
//  Created by Carmelo I. Uria on 5/19/13.
//  Copyright (c) 2013 Carmelo Uria Corporation. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "LottoProcessor.h"

extern NSString* const PBCompletedPowerballProcessor;

@class LotteryResultsGame;

@interface PowerballProcessor : LottoProcessor

- (void) processLottoNumbers;
- (BOOL) hasPowerballNumbers;

- (void) retrievePowerballWinnersWithCount:(NSInteger) count whiteBallGenerationType:(LottoGenerationType) generationType powerballGenerationType:(LottoGenerationType) powerballGenerationType;

@end
