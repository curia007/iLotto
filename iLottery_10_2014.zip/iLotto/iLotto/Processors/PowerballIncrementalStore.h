//
//  PowerballIncrementalStore.h
//  SampleLotto
//
//  Created by Carmelo I. Uria on 5/19/13.
//  Copyright (c) 2013 Carmelo Uria Corporation. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PowerballIncrementalStore : NSIncrementalStore

@end
