//
//  USLotteryFeedProcessor.m
//  SampleLotto
//
//  Created by Carmelo I. Uria on 5/3/13.
//  Copyright (c) 2013 Carmelo Uria Corporation. All rights reserved.
//

#import "USLotteryFeedProcessor.h"

#import "LotteryResultsGame.h"

#define kMegaMillionsLotteryType  0
#define kPowerballLotteryType  1

@interface USLotteryFeedProcessor ()
{
    BOOL isItemElement;
    BOOL isCharactersFound;
    BOOL isMegaMillionsLotto;
    BOOL isPowerballLotto;
}

@property (nonatomic, strong) NSMutableString *value;
@property (nonatomic, strong) NSString *title;
@property (nonatomic, strong) LotteryResultsGame *lotteryResultsGame;

@property (nonatomic, strong) NSMutableArray *results;

@property (nonatomic, strong) NSString *megaMillionsDescription;
@property (nonatomic, strong) NSString *powerballDescription;

- (void) parseDescriptionWithLotteryType:(NSInteger) lotteryType description:(NSString *) description;

@end

@implementation USLotteryFeedProcessor

- (void) parseDescriptionWithLotteryType:(NSInteger) lotteryType description:(NSString *) description
{
        
    NSArray *lines = [description componentsSeparatedByString:@"=="];
    
    LotteryResultsGame *results = [[LotteryResultsGame alloc] init];
    [results setInformation:[lines lastObject]];
    
    if (lotteryType == kMegaMillionsLotteryType)
    {
        [results setName:kMegaMillions];
    }
    else if (lotteryType == kPowerballLotteryType)
    {
        [results setName:kPowerball];
    }
    
    NSString *numbersString = [lines objectAtIndex:1];
    
    NSLog(@"numbers : %@", numbersString);
    
    NSArray *numbersArray = [numbersString componentsSeparatedByString:@"**"];
    NSArray *whiteNumbersArray = [[numbersArray objectAtIndex:0] componentsSeparatedByString:@"-"];
    
    NSMutableSet *numbers = [NSMutableSet setWithCapacity:5];
    
    [whiteNumbersArray enumerateObjectsUsingBlock:^(NSString *whiteNumber, NSUInteger idx, BOOL *stop) {
        [numbers addObject:[NSNumber numberWithInt:[whiteNumber intValue]]];
    }];
    
    [results setNumbers:numbers];
    
    NSArray *powerInformationArray = [[numbersArray lastObject] componentsSeparatedByString:@"x"];

    NSLog(@"power number = %@", [powerInformationArray objectAtIndex:0]);

    if ([powerInformationArray count] > 1)
    {
        NSLog(@"power multipilier = %@", [powerInformationArray lastObject]);
        [results setMultipilier:[[powerInformationArray lastObject] integerValue]];
    }
    
    [results setDate:[[self lotteryResultsGame] date]];
    
    [[self results] addObject:results];
}

NSString *kMegaMillions = @"Mega Millions";
NSString *kPowerball = @"Powerball";

NSString *kChannelElement = @"channel";
NSString *kTitleElement = @"title";
NSString *kLinkElement = @"link";
NSString *kDescriptionElement = @"description";
NSString *kPublishDateElement = @"pubDate";
NSString *kGUIDElement = @"guid";
NSString *kItemElement = @"item";
NSString *kLanguageElement = @"language";

#pragma mark -
#pragma mark NSXMLParserDelegate Methods

- (void) parser:(NSXMLParser *) parser foundCharacters:(NSString *) string
{
    [[self value] appendString:string];
}

- (void) parserDidStartDocument:(NSXMLParser *) parser
{
}

- (void) parserDidEndDocument:(NSXMLParser *) parser
{
    _results = [NSMutableArray arrayWithCapacity:1];
    
    [self parseDescriptionWithLotteryType:kPowerballLotteryType description:[self powerballDescription]];
    [self parseDescriptionWithLotteryType:kMegaMillionsLotteryType description:[self megaMillionsDescription]];
    
    
    [[self lotteryProcessorDelegate] lotteryFeedProcessor:self completedWithResults:[self results]];
}

- (void) parser:(NSXMLParser *) parser didStartElement:(NSString *) elementName namespaceURI:(NSString *) namespaceURI qualifiedName:(NSString *) qualifiedName attributes:(NSDictionary *) attributeDictionary
{    
    if ([elementName isEqualToString:kItemElement] == YES)
    {
        isItemElement = YES;
    }
    else if ([elementName isEqualToString:kTitleElement] == YES)
    {
        if (isItemElement == YES)
        {
            isCharactersFound = YES;
            [self setValue:nil];
            _value = [[NSMutableString alloc] init];
        }
    }
    else if ([elementName isEqualToString:kDescriptionElement] == YES)
    {
        if (isItemElement == YES)
        {
            isCharactersFound = YES;
            [self setValue:nil];
            _value = [[NSMutableString alloc] init];
        }
    }

}

- (void) parser:(NSXMLParser *) parser didEndElement:(NSString *) elementName namespaceURI:(NSString *) namespaceURI qualifiedName:(NSString *) qName
{    
    if ([elementName isEqualToString:kItemElement] == YES)
    {
        isItemElement = NO;
    }
    else if ([elementName isEqualToString:kTitleElement] == YES)
    {
        if (isItemElement == YES)
        {
            isCharactersFound = NO;
            
            // check for MegaMillions
            NSRange megaMillionsRange = NSMakeRange(0, [kMegaMillions length]);
            if ([[self value] compare:kMegaMillions options:NSCaseInsensitiveSearch range:megaMillionsRange] == NSOrderedSame)
            {
                // MegaMillions game found;  extract the date
                NSArray *components = [[self value] componentsSeparatedByString:@": "];
                NSLog(@" date : %@", [components lastObject]);
                NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
                NSString *usFormatString = [NSDateFormatter dateFormatFromTemplate:@"EdMMM" options:0 locale:[[NSLocale alloc] initWithLocaleIdentifier:@"us-en"]];
                [formatter setDateFormat:usFormatString];
                NSDate *date = [formatter dateFromString:[components lastObject]];

                NSCalendar *gregorian = [[NSCalendar alloc] initWithCalendarIdentifier:NSGregorianCalendar];
                NSDateComponents *dateComponents = [gregorian components:NSYearCalendarUnit | NSMonthCalendarUnit | NSDayCalendarUnit fromDate:date];

                NSDateComponents *currentComponents = [gregorian components:NSYearCalendarUnit fromDate:[NSDate date]];
                
                [dateComponents setYear:[currentComponents year]];
                
                _lotteryResultsGame = [[LotteryResultsGame alloc] init];
                [[self lotteryResultsGame] setDate:[gregorian dateFromComponents:dateComponents]];
                
                isMegaMillionsLotto = YES;
            }
            
            // Check for Powerball
            NSRange powerballRange = NSMakeRange(0, [kPowerball length]);
            if ([[self value] compare:kPowerball options:NSCaseInsensitiveSearch range:powerballRange] == NSOrderedSame)
            {
                // Powerball game found;  extract the date
                NSArray *components = [[self value] componentsSeparatedByString:@": "];
                NSLog(@" date : %@", [components lastObject]);
                NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
                NSString *usFormatString = [NSDateFormatter dateFormatFromTemplate:@"EdMMM" options:0 locale:[[NSLocale alloc] initWithLocaleIdentifier:@"us-en"]];
                [formatter setDateFormat:usFormatString];
                NSDate *date = [formatter dateFromString:[components lastObject]];
                
                NSCalendar *gregorian = [[NSCalendar alloc] initWithCalendarIdentifier:NSGregorianCalendar];
                NSDateComponents *dateComponents = [gregorian components:NSYearCalendarUnit | NSMonthCalendarUnit | NSDayCalendarUnit fromDate:date];
                
                NSDateComponents *currentComponents = [gregorian components:NSYearCalendarUnit fromDate:[NSDate date]];
                
                [dateComponents setYear:[currentComponents year]];
                
                _lotteryResultsGame = [[LotteryResultsGame alloc] init];
                [[self lotteryResultsGame] setDate:[gregorian dateFromComponents:dateComponents]];
                
                isPowerballLotto = YES;
            }

        }
    }
    else if ([elementName isEqualToString:kDescriptionElement] == YES)
    {
        if (isItemElement == YES)
        {
            isCharactersFound = NO;
           
            if (isMegaMillionsLotto == YES)
            {
                NSLog(@"MegaMillions description : %@", [self value]);
                _megaMillionsDescription = [self value];
                [self setValue:nil];
                isMegaMillionsLotto = NO;
            }
            else if (isPowerballLotto == YES)
            {
                NSLog(@"Powerball description : %@", [self value]);
                _powerballDescription = [self value];
                [self setValue:nil];
                isPowerballLotto = NO;
            }

        }
    }
    
}

@end
