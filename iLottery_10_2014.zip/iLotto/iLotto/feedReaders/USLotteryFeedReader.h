//
//  USLotteryFeedReader.h
//  SampleLotto
//
//  Created by Carmelo I. Uria on 5/3/13.
//  Copyright (c) 2013 Carmelo Uria Corporation. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "USLotteryFeedProcessor.h"

@class USLotteryFeedReader;

@protocol USLotteryFeedReaderDelegate <NSObject>

- (void) lotteryFeedReader:(USLotteryFeedReader *) reader completedWithError:(NSError *) error;
- (void) lotteryFeedReader:(USLotteryFeedReader *) reader completedWithResults:(NSArray *) results;

@end

@interface USLotteryFeedReader : NSObject <USLotteryFeedProcessorDelegate>

@property (nonatomic, assign) id<USLotteryFeedReaderDelegate> delegate;

- (void) processResults;

@end
