//
//  USLotteryFeedProcessor.h
//  SampleLotto
//
//  Created by Carmelo I. Uria on 5/3/13.
//  Copyright (c) 2013 Carmelo Uria Corporation. All rights reserved.
//

#import <Foundation/Foundation.h>

@class USLotteryFeedProcessor;

@protocol USLotteryFeedProcessorDelegate

- (void) lotteryFeedProcessor:(USLotteryFeedProcessor *) processor completedWithError:(NSError *) error;
- (void) lotteryFeedProcessor:(USLotteryFeedProcessor *) processor completedWithResults:(NSArray *) results;

@end

@interface USLotteryFeedProcessor : NSObject <NSXMLParserDelegate>

@property (nonatomic, assign) id<USLotteryFeedProcessorDelegate> lotteryProcessorDelegate;

@end
