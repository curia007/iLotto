//
//  USLotteryFeedReader.m
//  SampleLotto
//
//  Created by Carmelo I. Uria on 5/3/13.
//  Copyright (c) 2013 Carmelo Uria Corporation. All rights reserved.
//

#import "USLotteryFeedReader.h"

@interface USLotteryFeedReader ()

@property (nonatomic, strong) NSOperationQueue *operationQueue;
@property (nonatomic, strong) USLotteryFeedProcessor *feedProcessor;

@end

@implementation USLotteryFeedReader

- (void) processResults
{
    NSLog(@"Starting Test...");
    
    NSURL *californiaLotteryFeedURL = [NSURL URLWithString:@"http://www.us-lotteries.com/rss/IDRss.xml"];
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:californiaLotteryFeedURL];

    _operationQueue = [NSOperationQueue currentQueue];
    [NSURLConnection sendAsynchronousRequest:request queue:self.operationQueue completionHandler:^(NSURLResponse *response, NSData *data, NSError *error)
    {
        // parse the data
        NSXMLParser *feedParser = [[NSXMLParser alloc] initWithData:data];
        _feedProcessor = [[USLotteryFeedProcessor alloc] init];
        [feedParser setDelegate:[self feedProcessor]];
        [[self feedProcessor] setLotteryProcessorDelegate:self];
        BOOL isParsingComplete = [feedParser parse];
        
        if (isParsingComplete == YES)
        {
            NSLog(@"Parsing is complete...");
        }
        else
        {
            NSLog(@"Parsing is not complete...");
        }
    }];
}

#pragma mark -
#pragma mark USLotteryFeedProcessorDelegate methods
- (void) lotteryFeedProcessor:(USLotteryFeedProcessor *) processor completedWithError:(NSError *) error
{
    [[self delegate] lotteryFeedReader:self completedWithError:error];
}

- (void) lotteryFeedProcessor:(USLotteryFeedProcessor *) processor completedWithResults:(NSArray *) results
{
    if ([self delegate] == nil)
    {
        NSLog(@"delegate is nil");
    }
    else
    {
        NSLog(@"delegate description : %@", [[self delegate] description]);
    }

    
    [[self delegate] lotteryFeedReader:self completedWithResults:results];
}

@end
