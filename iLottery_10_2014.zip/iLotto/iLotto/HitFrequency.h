//
//  HitFrequency.h
//  iLotto
//
//  Created by Carmelo I. Uria on 7/25/13.
//  Copyright (c) 2013 Carmelo Uria Corporation. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>


@interface HitFrequency : NSManagedObject

@property (nonatomic, retain) NSNumber * lottoNumber;
@property (nonatomic, retain) NSNumber * hitCount;
@property (nonatomic, retain) NSNumber * moneyCount;
@property (nonatomic, retain) NSString * type;

@end
