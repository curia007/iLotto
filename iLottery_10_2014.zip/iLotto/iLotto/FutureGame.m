//
//  FutureGame.m
//  iLotto
//
//  Created by Carmelo I. Uria on 1/8/14.
//  Copyright (c) 2014 Carmelo Uria Corporation. All rights reserved.
//

#import "FutureGame.h"
#import "FutureTicket.h"


@implementation FutureGame

@dynamic lottoDate;
@dynamic type;
@dynamic tickets;

@end
