//
//  FutureGame.h
//  iLotto
//
//  Created by Carmelo I. Uria on 1/8/14.
//  Copyright (c) 2014 Carmelo Uria Corporation. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>

@class FutureTicket;

@interface FutureGame : NSManagedObject

@property (nonatomic, retain) NSString * lottoDate;
@property (nonatomic, retain) NSString * type;
@property (nonatomic, retain) NSSet *tickets;
@end

@interface FutureGame (CoreDataGeneratedAccessors)

- (void)addTicketsObject:(FutureTicket *)value;
- (void)removeTicketsObject:(FutureTicket *)value;
- (void)addTickets:(NSSet *)values;
- (void)removeTickets:(NSSet *)values;

@end
