//
//  Powerball.m
//  iLotto
//
//  Created by Carmelo I. Uria on 7/25/13.
//  Copyright (c) 2013 Carmelo Uria Corporation. All rights reserved.
//

#import "Powerball.h"


@implementation Powerball

@dynamic date;
@dynamic pb;
@dynamic pp;
@dynamic wb1;
@dynamic wb2;
@dynamic wb3;
@dynamic wb4;
@dynamic wb5;

@end
