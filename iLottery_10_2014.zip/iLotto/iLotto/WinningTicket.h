//
//  WinningTicket.h
//  iLotto
//
//  Created by Carmelo I. Uria on 8/6/13.
//  Copyright (c) 2013 Carmelo Uria Corporation. All rights reserved.
//

#import <Foundation/Foundation.h>

#import "LottoProcessor.h"

@interface WinningTicket : NSObject

@property (nonatomic, strong) NSString *date;
@property (nonatomic, strong) NSArray *numbers;
@property (assign) NSInteger moneyNumber;
@property (assign) LottoType lottoType;

- (id) initWithLottoType:(LottoType) lottoType date:(NSString *) date whiteNumbers:(NSArray *) whiteNumbers moneyball:(NSInteger) moneyball;

@end
