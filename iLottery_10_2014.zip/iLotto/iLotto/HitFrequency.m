//
//  HitFrequency.m
//  iLotto
//
//  Created by Carmelo I. Uria on 7/25/13.
//  Copyright (c) 2013 Carmelo Uria Corporation. All rights reserved.
//

#import "HitFrequency.h"


@implementation HitFrequency

@dynamic lottoNumber;
@dynamic hitCount;
@dynamic moneyCount;
@dynamic type;

@end
