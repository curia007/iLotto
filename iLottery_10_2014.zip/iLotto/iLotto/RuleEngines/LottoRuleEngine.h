//
//  LottoRuleEngine.h
//  iLotto
//
//  Created by Carmelo I. Uria on 1/10/14.
//  Copyright (c) 2014 Carmelo Uria Corporation. All rights reserved.
//

#import <Foundation/Foundation.h>

#import "LottoProcessor.h"

@interface LottoRuleEngine : NSObject

@property (nonatomic, assign) LottoType lottoType;

- (void) analizeWithComponents:(NSArray *) components;

@end
