//
//  LottoRuleEngine.m
//  iLotto
//
//  Created by Carmelo I. Uria on 1/10/14.
//  Copyright (c) 2014 Carmelo Uria Corporation. All rights reserved.
//

#import "LottoRuleEngine.h"

@implementation LottoRuleEngine

- (void) analizeWithComponents:(NSArray *) components
{
    NSAssert(components != nil, @"<%s>  components cannot be nil", __PRETTY_FUNCTION__);
    
    __block NSInteger scoring = 0;
    
    [components enumerateObjectsUsingBlock:^(NSString *word, NSUInteger idx, BOOL *stop) {
       
#ifdef DEBUG
        NSLog(@"word: %@", word);
#endif
        if ([word floatValue] > 0.0 )
        {
            float numberOfTickets = [word floatValue];
            scoring++;
#ifdef DEBUG
            NSLog(@"number of tickets: %f", numberOfTickets);
#endif
        }
        if (([word compare:@"megamillions" options:NSCaseInsensitiveSearch] == NSOrderedSame) | ([word compare:@"powerball" options:NSCaseInsensitiveSearch] == NSOrderedSame))
        {
            // set lotto type
            if ([word compare:@"megamillions" options:NSCaseInsensitiveSearch] == NSOrderedSame)
            {
                [self setLottoType:kMegaMillionsLottoType];
            }
            else
            {
                [self setLottoType:kPowerballLottoType];
            }
            
            scoring++;
        }
    }];
}

@end
