//
//  WinningTicket.m
//  iLotto
//
//  Created by Carmelo I. Uria on 8/6/13.
//  Copyright (c) 2013 Carmelo Uria Corporation. All rights reserved.
//

#import "WinningTicket.h"

@implementation WinningTicket

- (id) initWithLottoType:(LottoType) lottoType date:(NSString *) date whiteNumbers:(NSArray *) whiteNumbers moneyball:(NSInteger) moneyball
{
    self = [super init];
    
    if (self != nil)
    {
        [self setLottoType:lottoType];
        [self setDate:date];
        [self setNumbers:whiteNumbers];
        [self setMoneyNumber:moneyball];
    }
    
    return self;
}


@end
