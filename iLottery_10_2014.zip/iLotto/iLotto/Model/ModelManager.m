//
//  ModelManager.m
//  SampleLotto
//
//  Created by Carmelo I. Uria on 7/24/13.
//  Copyright (c) 2013 Carmelo Uria Corporation. All rights reserved.
//

#import "ModelManager.h"

#import "MegaMillions.h"
#import "Powerball.h"
#import "HitFrequency.h"
#import "FutureGame.h"

#import "FutureTicket.h"
#import "WinningTicket.h"

NSString * kiCloudPersistentStoreFilename = @"iCloudLotto.sqlite";
NSString * kConsultingModel = @"LottoModel";
NSString * kLocalStoreFilename = @"LottoModel.sqlite"; //holds the states information
NSString * kPrefixIdentifier = @"32SL43PW6T";

#define SEED_ICLOUD_STORE YES

@interface ModelManager ()

@property (nonatomic, strong) NSManagedObjectContext *managedObjectContext;
@property (nonatomic, strong) NSManagedObjectModel *managedObjectModel;
@property (nonatomic, strong) NSPersistentStoreCoordinator *persistentStoreCoordinator;

@property (nonatomic, strong) NSFileManager *fileManager;

- (NSURL *) applicationDocumentsDirectory;
- (void) mergeChangesFromCloud:(NSNotification *) notification;
- (void) processResultsWithError:(NSError *) error results:(id) results;

- (void) insertFrequencyWithNumber:(NSInteger) lottoNumber moneyBall:(BOOL) isMoneyBall lottoType:(NSString *) lottoType;
- (void) updateFrequencyWithEntity:(HitFrequency *) hitFrequency isMoneyBall:(BOOL) isMoneyBall;

@end

@implementation ModelManager

- (void) mergeChangesFromCloud:(NSNotification *) notification
{
    
	NSLog(@"Merging in changes from iCloud...");
    
    NSManagedObjectContext *managedObjectContext = [self managedObjectContext];
    
    [managedObjectContext performBlock:^{
        
        [managedObjectContext mergeChangesFromContextDidSaveNotification:notification];
        
        NSNotification* refreshNotification = [NSNotification notificationWithName:@"SomethingChanged"
                                                                            object:self
                                                                          userInfo:[notification userInfo]];
        
        [[NSNotificationCenter defaultCenter] postNotification:refreshNotification];
    }];
}


- (void) processResultsWithError:(NSError *) error results:(id) results
{
    if (error != nil)
    {
        if ([self delegate] != nil)
        {
            [[self delegate] modelManager:self didFailWithError:error];
        }
        else
        {
            NSString *message = [error description];
            
            // Show alert on the main thread
            dispatch_async(dispatch_get_main_queue(), ^{
                // Showing the alert for unattending
                UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Error" message:message delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil, nil];
                [alert show];
            });
            
        }
    }
    else
    {
        if ([self delegate] != nil)
        {
            [[self delegate] modelManagerDidFinish:self results:nil];
        }
    }
}

- (BOOL) isMegaMillionsInformationExistsWithDate:(NSString *) date;
{
    NSManagedObjectContext *managedObjectContext = [self managedObjectContext];
    
    __block NSArray *entities = nil;
    __block BOOL megaMillionsExist = NO;
    
    [managedObjectContext performBlockAndWait:^{
        NSError *blockError = nil;
        NSDictionary *substitutionVariables = [NSDictionary dictionaryWithObject:date forKey:@"LOTTO_DATE"];

        NSFetchRequest *fetchRequest = [[self managedObjectModel] fetchRequestFromTemplateWithName:@"MegaMillionsFetchRequestWithDate" substitutionVariables:substitutionVariables];
     
        entities = [managedObjectContext executeFetchRequest:fetchRequest error:&blockError];
        
        if (blockError != nil)
        {
            NSLog(@"%s:  %@", __PRETTY_FUNCTION__, [blockError description]);
            megaMillionsExist = NO;
        }
        else
        {
            if ([entities count] == 0)
            {
                megaMillionsExist = NO;
            }
            else
            {
                megaMillionsExist = YES;
            }
        }
    }];
    
    return megaMillionsExist;
}

- (void) removeMegaMillionsInformation
{
    NSManagedObjectContext *managedObjectContext = [self managedObjectContext];
    
    __block NSArray *entities = nil;
    NSError __autoreleasing *error = nil;
    
    [managedObjectContext performBlockAndWait:^{
        NSError *blockError = nil;
        NSFetchRequest *fetchRequest = [[self managedObjectModel] fetchRequestTemplateForName:@"MegaMillionsFetchRequest"];
        entities = [managedObjectContext executeFetchRequest:fetchRequest error:&blockError];
        
        if (blockError != nil)
        {
            NSLog(@"%s:  %@", __PRETTY_FUNCTION__, [blockError description]);
        }
        else
        {
            [entities enumerateObjectsUsingBlock:^(NSManagedObject *managedObject, NSUInteger idx, BOOL *stop) {
                [managedObjectContext deleteObject:managedObject];
            }];
        }
    }];
    
    [managedObjectContext save:&error];
    
    if (error != nil)
    {
        if ([self delegate] != nil)
        {
            [[self delegate] modelManager:self didFailWithError:error];
        }
    }
    else
    {
        if ([self delegate] != nil)
        {
            [[self delegate] modelManagerDidFinish:self results:nil];
        }        
    }
}

- (BOOL) isPowerballInformationExistsWithDate:(NSString *) date;
{
    NSManagedObjectContext *managedObjectContext = [self managedObjectContext];
    
    __block NSArray *entities = nil;
    __block BOOL entityExist = NO;
    
    [managedObjectContext performBlockAndWait:^{
        NSError *blockError = nil;
        NSDictionary *substitutionVariables=[NSDictionary dictionaryWithObject:date forKey:@"LOTTO_DATE"];
        
        NSFetchRequest *fetchRequest = [[self managedObjectModel] fetchRequestFromTemplateWithName:@"PowerballFetchRequestWithDate" substitutionVariables:substitutionVariables];
        
        entities = [managedObjectContext executeFetchRequest:fetchRequest error:&blockError];
        
        if (blockError != nil)
        {
            NSLog(@"%s:  %@", __PRETTY_FUNCTION__, [blockError description]);
            entityExist = NO;
        }
        else
        {
            if ([entities count] == 0)
            {
                entityExist = NO;
            }
            else
            {
                entityExist = YES;
            }
        }
    }];
    
    return entityExist;
}

- (void) removePowerballInformation
{
    NSManagedObjectContext *managedObjectContext = [self managedObjectContext];
    
    __block NSArray *entities = nil;
    NSError __autoreleasing *error = nil;
    
    [managedObjectContext performBlockAndWait:^{
        NSError *blockError = nil;
        NSFetchRequest *fetchRequest = [[self managedObjectModel] fetchRequestTemplateForName:@"PowerballFetchRequest"];
        entities = [managedObjectContext executeFetchRequest:fetchRequest error:&blockError];
        
        if (blockError != nil)
        {
            NSLog(@"%s:  %@", __PRETTY_FUNCTION__, [blockError description]);
        }
        else
        {
            [entities enumerateObjectsUsingBlock:^(NSManagedObject *managedObject, NSUInteger idx, BOOL *stop) {
                [managedObjectContext deleteObject:managedObject];
            }];
        }
    }];
    
    [managedObjectContext save:&error];
    
    if (error != nil)
    {
        if ([self delegate] != nil)
        {
            [[self delegate] modelManager:self didFailWithError:error];
        }
    }
    else
    {
        if ([self delegate] != nil)
        {
            [[self delegate] modelManagerDidFinish:self results:nil];
        }
    }
}

- (NSArray *) retrieveMegaMillions
{
    NSManagedObjectContext *managedObjectContext = [self managedObjectContext];
    
    __block NSArray *entities = nil;
    
    [managedObjectContext performBlockAndWait:^{
        NSError *blockError = nil;
        
        NSFetchRequest *fetchRequest = [[self managedObjectModel] fetchRequestTemplateForName:@"PowerballFetchRequest"];
        
        entities = [managedObjectContext executeFetchRequest:fetchRequest error:&blockError];
        
    }];
    
    return entities;    
}

- (NSArray *) retrievePowerball
{
    NSManagedObjectContext *managedObjectContext = [self managedObjectContext];
    
    __block NSArray *entities = nil;
    
    [managedObjectContext performBlockAndWait:^{
        NSError *blockError = nil;
        
        NSFetchRequest *fetchRequest = [[self managedObjectModel] fetchRequestTemplateForName:@"PowerballFetchRequest"];
        
        entities = [managedObjectContext executeFetchRequest:fetchRequest error:&blockError];
        
    }];
    
    return entities;
}

- (void) addFrequencyWithNumber:(NSInteger) lottoNumber moneyBall:(BOOL) isMoneyBall lottoType:(NSString *) lottoType
{
    NSManagedObjectContext *managedObjectContext = [self managedObjectContext];
    
    __block NSArray *entities = nil;
    
    [managedObjectContext performBlockAndWait:^{
        NSError *blockError = nil;
        
        NSNumber *lottoNumberObject = [NSNumber numberWithInteger:lottoNumber];
        
        NSDictionary *substitutionVariables = [NSDictionary dictionaryWithObjectsAndKeys:lottoType, @"LOTTO_TYPE",lottoNumberObject,  @"LOTTO_NUMBER", nil];
        
        NSFetchRequest *fetchRequest = [[self managedObjectModel] fetchRequestFromTemplateWithName:@"CheckFrequencyNumberFetchRequest" substitutionVariables:substitutionVariables];
        
        entities = [managedObjectContext executeFetchRequest:fetchRequest error:&blockError];
        
        if (blockError != nil)
        {
            NSLog(@"%s:  %@", __PRETTY_FUNCTION__, [blockError description]);
        }
        else
        {
            if ([entities count] == 0)
            {
                [self insertFrequencyWithNumber:lottoNumber moneyBall:isMoneyBall lottoType:lottoType];
            }
            else
            {
                [self updateFrequencyWithEntity:[entities lastObject] isMoneyBall:isMoneyBall];
            }
        }
    }];
}

- (void) insertFrequencyWithNumber:(NSInteger) lottoNumber moneyBall:(BOOL) isMoneyBall lottoType:(NSString *) lottoType
{
    NSError *error = nil;
    HitFrequency *hitFrequency =(HitFrequency *)[NSEntityDescription insertNewObjectForEntityForName:@"HitFrequency" inManagedObjectContext:[self managedObjectContext]];
 
    [hitFrequency setLottoNumber:[NSNumber numberWithInteger:lottoNumber]];
    if ([lottoType compare:@"powerball" options:NSCaseInsensitiveSearch] == NSOrderedSame)
    {
        [hitFrequency setType:@"powerball"];
    }
    else if ([lottoType compare:@"megamillions" options:NSCaseInsensitiveSearch] == NSOrderedSame)
    {
        [hitFrequency setType:@"megamillions"];
    }
    
    if (isMoneyBall == YES)
    {
        [hitFrequency setHitCount:[NSNumber numberWithInt:0]];
        [hitFrequency setMoneyCount:[NSNumber numberWithInt:1]];
    }
    else
    {
        [hitFrequency setHitCount:[NSNumber numberWithInt:1]];
        [hitFrequency setMoneyCount:[NSNumber numberWithInt:0]];
    }
    
    [[self managedObjectContext] save:&error];
}

- (void) updateFrequencyWithEntity:(HitFrequency *) hitFrequency isMoneyBall:(BOOL) isMoneyBall;
{
    NSError *error = nil;
    
    if (isMoneyBall == YES)
    {
        int lottoValue = [[hitFrequency moneyCount] intValue];
        lottoValue++;
        
        [hitFrequency setMoneyCount:[NSNumber numberWithInt:lottoValue]];
        [[self managedObjectContext] save:&error];
    }
    else
    {
        int lottoValue = [[hitFrequency hitCount] intValue];
        lottoValue++;
        
        [hitFrequency setHitCount:[NSNumber numberWithInt:lottoValue]];
        [[self managedObjectContext] save:&error];
    }
}

- (NSArray *) retrieveFrequencyWithSortDescriptor:(NSSortDescriptor *) sortDescriptor lottoType:(NSString *) lottoType
{
    NSAssert(sortDescriptor != nil, @"Sort Descriptor cannot be nil");
    
    NSString *fetchRequestTemplateName = nil;
    
    if ([lottoType compare:@"powerball" options:NSCaseInsensitiveSearch] == NSOrderedSame)
    {
        fetchRequestTemplateName = @"PowerballHitFrequency";
    }
    else if ([lottoType compare:@"megamillions" options:NSCaseInsensitiveSearch] == NSOrderedSame)
    {
        fetchRequestTemplateName = @"MegaMillionsHitFrequency";
    }
 
    NSError *error = nil;
    NSManagedObjectContext *managedObjectContext = [self managedObjectContext];
 
    NSFetchRequest *fetchRequest = [[NSFetchRequest alloc] initWithEntityName:@"HitFrequency"];
    
    [fetchRequest setSortDescriptors:[NSArray arrayWithObject:sortDescriptor]];
    NSArray *entities = [managedObjectContext executeFetchRequest:fetchRequest error:&error];
    
    return entities;
}


- (NSArray *) retrieveFrequencyWithSortDescriptors:(NSArray *) sortDescriptors
{
    NSAssert(sortDescriptors != nil, @"Sort Descriptors cannot be nil");
    
    NSManagedObjectContext *managedObjectContext = [self managedObjectContext];
    
    __block NSArray *entities = nil;
    
    [managedObjectContext performBlockAndWait:^{
        NSError *blockError = nil;
        
        NSFetchRequest *fetchRequest = [[NSFetchRequest alloc] initWithEntityName:@"HitFrequency"];
        
        [fetchRequest setSortDescriptors:sortDescriptors];
        entities = [managedObjectContext executeFetchRequest:fetchRequest error:&blockError];
        
    }];
    
    return entities;
}

- (NSArray *) retrieveFutureGameWithDate:(NSString *) date
{
    NSManagedObjectContext *managedObjectContext = [self managedObjectContext];
    __block NSArray *entities = nil;
    
    [managedObjectContext performBlockAndWait:^{
        NSError *blockError = nil;
        
        NSDictionary *substitutionVariables = [NSDictionary dictionaryWithObjectsAndKeys:date, @"LOTTO_DATE", nil];
        NSFetchRequest *fetchRequest = [[self managedObjectModel] fetchRequestFromTemplateWithName:@"FutureGameFetchRequestWithDate" substitutionVariables:substitutionVariables];
        
        entities = [managedObjectContext executeFetchRequest:fetchRequest error:&blockError];
        
    }];
    
    return entities;
}

- (NSArray *) retrieveFutureTicketsWithDate:(NSString *) date
{
    NSManagedObjectContext *managedObjectContext = [self managedObjectContext];
    __block NSArray *entities = nil;
    
    [managedObjectContext performBlockAndWait:^{
        NSError *blockError = nil;
        
        NSDictionary *substitutionVariables = [NSDictionary dictionaryWithObjectsAndKeys:@"DATE", date, nil];
        NSFetchRequest *fetchRequest = [[self managedObjectModel] fetchRequestFromTemplateWithName:@"FutureTicketFetchRequest" substitutionVariables:substitutionVariables];
        
        entities = [managedObjectContext executeFetchRequest:fetchRequest error:&blockError];
        
    }];
    
    return entities;
}

- (void) insertFutureTicketWithWinningTickets:(NSArray *) winningTickets
{
    NSAssert(winningTickets !=  nil, @"%s:  winningTickets array cannot be nil", __PRETTY_FUNCTION__);
    
    NSError *error = nil;
    
    NSManagedObjectContext *managedObjectContext = [self managedObjectContext];
    
    [winningTickets enumerateObjectsUsingBlock:^(id obj, NSUInteger idx, BOOL *stop) {
        WinningTicket *winningTicket = (WinningTicket *) obj;
#ifdef DEBUG
        NSLog(@"winning ticket:  [date] %@", [winningTicket date]);
#endif
        
        // check winning ticket by date
        NSString *date = [winningTicket date];

        NSArray *futureGames = [self retrieveFutureGameWithDate:date];
        
        if ((futureGames == nil) | ([futureGames count] == 0))
        {
            // insert new game
            FutureGame *futureGame =(FutureGame *)[NSEntityDescription insertNewObjectForEntityForName:@"FutureGame" inManagedObjectContext:managedObjectContext];
            
            FutureTicket *futureTicket =(FutureTicket *)[NSEntityDescription insertNewObjectForEntityForName:@"FutureTicket" inManagedObjectContext:managedObjectContext];

            if ([winningTicket lottoType] == kPowerballLottoType)
            {
                [futureGame setType:@"powerball"];
            }
            else if ([winningTicket lottoType] == kMegaMillionsLottoType)
            {
                [futureGame setType:@"megamillions"];
            }
            
            [futureGame setLottoDate:date];
            
            [futureTicket setDate:date];
            [futureTicket setMoneyball:[NSNumber numberWithInteger:[winningTicket moneyNumber]]];
            [futureTicket setWhiteballs:[NSArray arrayWithArray:winningTicket.numbers]];
            [futureTicket setGame:futureGame];
            
            [futureGame setTickets:[NSSet setWithObject:futureTicket]];
        }
        else
        {
            // update game
            FutureGame *futureGame = (FutureGame *)[futureGames firstObject];
            FutureTicket *futureTicket =(FutureTicket *)[NSEntityDescription insertNewObjectForEntityForName:@"FutureTicket" inManagedObjectContext:managedObjectContext];
            
            if ([winningTicket lottoType] == kPowerballLottoType)
            {
                [futureGame setType:@"powerball"];
            }
            else if ([winningTicket lottoType] == kMegaMillionsLottoType)
            {
                [futureGame setType:@"megamillions"];
            }
            
            [futureGame setLottoDate:date];
            
            [futureTicket setDate:date];
            [futureTicket setMoneyball:[NSNumber numberWithInteger:[winningTicket moneyNumber]]];
            [futureTicket setWhiteballs:[NSArray arrayWithArray:winningTicket.numbers]];
            [futureTicket setGame:futureGame];
            
            NSSet *tickets = [futureGame tickets];
            NSMutableSet *addedTickets = [NSMutableSet setWithSet:tickets];
            [addedTickets addObject:futureTicket];
            
            [futureGame setTickets:addedTickets];

        }
        
    }];
  
    [managedObjectContext save:&error];
    
    if (error != nil)
    {
        NSLog(@"%s[%@]: Issue adding future game and ticket entities [into CoreData", __PRETTY_FUNCTION__, [error description]);
    }

}

- (void) insertFutureTicketWithLottoType:(LottoType) lottoType date:(NSString *) date numbers:(NSArray *) numbers moneyball:(NSInteger) moneyball
{
    NSError *error = nil;
    
    FutureTicket *futureTicket =(FutureTicket *)[NSEntityDescription insertNewObjectForEntityForName:@"FutureTicket" inManagedObjectContext:[self managedObjectContext]];
    
    [futureTicket setDate:date];
    [futureTicket setWhiteballs:numbers];
    [futureTicket setMoneyball:[NSNumber numberWithInteger:moneyball]];

    [[self managedObjectContext] save:&error];
   
    // check error
    if (error != nil)
    {
        NSLog(@"error:  %@", error);
        
        // add notification
        
    }
}

- (void) updateFutureTicketWithLottoType:(LottoType) lottoType date:(NSString *) date numbers:(NSArray *) numbers moneyball:(NSInteger) moneyball
{
    NSError *error = nil;
    FutureTicket *futureTicket =(FutureTicket *)[NSEntityDescription insertNewObjectForEntityForName:@"FutureTicket" inManagedObjectContext:[self managedObjectContext]];
    
    [futureTicket setDate:date];
    [futureTicket setWhiteballs:numbers];
    [futureTicket setMoneyball:[NSNumber numberWithInteger:moneyball]];
    
    [[self managedObjectContext] save:&error];
    
    // check error
    if (error != nil)
    {
        NSLog(@"error:  %@", error);
        
        // add notification
        
    }
    
}


- (void) processWinningGameWithLottoType:(LottoType) lottoType tickets:(NSArray *) winningTickets date:(NSString *) date
{
    if (winningTickets == nil)
    {
        NSLog(@"%s Winning tickets array is nil", __PRETTY_FUNCTION__);
        return;
    }
    
    NSError *error = nil;
    NSManagedObjectContext *managedObjectContext = [self managedObjectContext];
    
    // check to see if future game exists
    NSArray *futureGames = [self retrieveFutureGameWithDate:date];
    
    if ((futureGames == nil) || ([futureGames count] == 0))
    {
        // update existing entities
        
        return;
    }
    
    // create FutureGame
    FutureGame *futureGame = (FutureGame *)[NSEntityDescription insertNewObjectForEntityForName:@"FutureGame" inManagedObjectContext:managedObjectContext];
    
    if (lottoType == kPowerballLottoType)
    {
        [futureGame setType:@"powerball"];
    }
    else if (lottoType == kMegaMillionsLottoType)
    {
        [futureGame setType:@"megamillions"];
    }
    
    [futureGame setLottoDate:date];
    
    NSMutableSet *set = [NSMutableSet setWithCapacity:[winningTickets count]];
    
    [winningTickets enumerateObjectsUsingBlock:^(WinningTicket *winningTicket, NSUInteger idx, BOOL *stop) {
        FutureTicket *futureTicket = (FutureTicket *)[NSEntityDescription insertNewObjectForEntityForName:@"FutureTicket" inManagedObjectContext:managedObjectContext];
        
        [futureTicket setGame:futureGame];
        [futureTicket setWhiteballs:[winningTicket numbers]];
        [futureTicket setMoneyball:[NSNumber numberWithInteger:[winningTicket moneyNumber]]];
        [set addObject:futureTicket];
    }];
    
    [futureGame setTickets:set];
    
    // save managed object context
    [managedObjectContext save:&error];
    
    if (error != nil)
    {
        NSLog(@"%s : %@", __PRETTY_FUNCTION__, [error description]);
    }
}

- (void) processWithLotteryResultsGame:(LotteryResultsGame *) lotteryResultsGame
{
    
}

- (BOOL) isFutureGameExistWithDate:(NSString *) date
{
    NSError *error = nil;
    
    NSDictionary *substitutionVariables = [NSDictionary dictionaryWithObjectsAndKeys:@"DATE", date, nil];
    NSFetchRequest *fetchRequest = [[self managedObjectModel] fetchRequestFromTemplateWithName:@"FutureGameFetchRequestWithDate" substitutionVariables:substitutionVariables];

    NSArray *entities = [[self managedObjectContext] executeFetchRequest:fetchRequest error:&error];
    
    if (entities == nil | [entities count] == 0)
    {
        return NO;
    }
    
    return YES;
}

#pragma mark
#pragma mark - Core Data stack

// Returns the managed object context for the application.
// If the context doesn't already exist, it is created and bound to the persistent store coordinator for the application.
- (NSManagedObjectContext *) managedObjectContext
{
    if (_managedObjectContext != nil)
    {
        return _managedObjectContext;
    }
    
    NSPersistentStoreCoordinator *coordinator = [self persistentStoreCoordinator];
    
    if (coordinator != nil)
    {
        NSManagedObjectContext *managedObjectContext = [[NSManagedObjectContext alloc] initWithConcurrencyType:NSPrivateQueueConcurrencyType];
        
        [managedObjectContext performBlockAndWait:^{
            [managedObjectContext setPersistentStoreCoordinator: coordinator];
            [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(mergeChangesFromCloud:) name:NSPersistentStoreDidImportUbiquitousContentChangesNotification object:coordinator];
        }];
        
        _managedObjectContext = managedObjectContext;
    }
    
    return _managedObjectContext;
}

// Returns the managed object model for the application.
// If the model doesn't already exist, it is created from the application's model.
- (NSManagedObjectModel *) managedObjectModel
{
    if (_managedObjectModel != nil)
    {
        return _managedObjectModel;
    }
    
    NSURL *modelURL = [[NSBundle mainBundle] URLForResource:kConsultingModel withExtension:@"momd"];
    _managedObjectModel = [[NSManagedObjectModel alloc] initWithContentsOfURL:modelURL];
    return _managedObjectModel;
}

// Returns the persistent store coordinator for the application.
// If the coordinator doesn't already exist, it is created and the application's store added to it.
- (NSPersistentStoreCoordinator *) persistentStoreCoordinator
{
    if((_persistentStoreCoordinator != nil))
    {
        return _persistentStoreCoordinator;
    }
    
    _persistentStoreCoordinator = [[NSPersistentStoreCoordinator alloc] initWithManagedObjectModel: [self managedObjectModel]];
    NSPersistentStoreCoordinator *persistentStoreCoordinator = _persistentStoreCoordinator;
    
    // Set up iCloud in another thread:
    
    //    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
    
    // ** Note: if you adapt this code for your own use, you MUST change this variable:
    NSString *iCloudEnabledAppID = [NSString stringWithFormat:@"%@.com.carmelouria.iLotto", kPrefixIdentifier];
    
    // ** Note: if you adapt this code for your own use, you should change this variable:
    NSString *dataFileName = kLocalStoreFilename;
    
    // ** Note: For basic usage you shouldn't need to change anything else
    
    NSString *iCloudDataDirectoryName = @"Data.nosync";
    NSString *iCloudLogsDirectoryName = @"Logs";
    
    NSFileManager *fileManager = [NSFileManager defaultManager];
    NSURL *localStore = [[self applicationDocumentsDirectory] URLByAppendingPathComponent:dataFileName];
    NSURL *iCloud = [fileManager URLForUbiquityContainerIdentifier:nil];
    
    if (iCloud)
    {
        
        NSLog(@"iCloud is working");
        
        NSURL *iCloudLogsPath = [NSURL fileURLWithPath:[[iCloud path] stringByAppendingPathComponent:iCloudLogsDirectoryName]];
        
        NSLog(@"iCloudEnabledAppID = %@",iCloudEnabledAppID);
        NSLog(@"dataFileName = %@", dataFileName);
        NSLog(@"iCloudDataDirectoryName = %@", iCloudDataDirectoryName);
        NSLog(@"iCloudLogsDirectoryName = %@", iCloudLogsDirectoryName);
        NSLog(@"iCloud = %@", iCloud);
        NSLog(@"iCloudLogsPath = %@", iCloudLogsPath);
        
        if([fileManager fileExistsAtPath:[[iCloud path] stringByAppendingPathComponent:iCloudDataDirectoryName]] == NO)
        {
            NSError *fileSystemError = nil;
            [fileManager createDirectoryAtPath:[[iCloud path] stringByAppendingPathComponent:iCloudDataDirectoryName]
                   withIntermediateDirectories:YES
                                    attributes:nil
                                         error:&fileSystemError];
            if(fileSystemError != nil)
            {
                NSLog(@"Error creating database directory %@", fileSystemError);
            }
        }
        
        NSString *iCloudData = [[[iCloud path]
                                 stringByAppendingPathComponent:iCloudDataDirectoryName]
                                stringByAppendingPathComponent:dataFileName];
        
        NSLog(@"iCloudData = %@", iCloudData);
        
        NSMutableDictionary *options = [NSMutableDictionary dictionary];
        [options setObject:[NSNumber numberWithBool:YES] forKey:NSMigratePersistentStoresAutomaticallyOption];
        [options setObject:[NSNumber numberWithBool:YES] forKey:NSInferMappingModelAutomaticallyOption];
        [options setObject:iCloudEnabledAppID            forKey:NSPersistentStoreUbiquitousContentNameKey];
        [options setObject:iCloudLogsPath                forKey:NSPersistentStoreUbiquitousContentURLKey];
        
        [persistentStoreCoordinator lock];
        
        [persistentStoreCoordinator addPersistentStoreWithType:NSSQLiteStoreType
                                                 configuration:nil
                                                           URL:[NSURL fileURLWithPath:iCloudData]
                                                       options:options
                                                         error:nil];
        
        [persistentStoreCoordinator unlock];
    }
    else
    {
        NSLog(@"iCloud is NOT working - using a local store");
        NSMutableDictionary *options = [NSMutableDictionary dictionary];
        [options setObject:[NSNumber numberWithBool:YES] forKey:NSMigratePersistentStoresAutomaticallyOption];
        [options setObject:[NSNumber numberWithBool:YES] forKey:NSInferMappingModelAutomaticallyOption];
        
        [persistentStoreCoordinator lock];
        
        [persistentStoreCoordinator addPersistentStoreWithType:NSSQLiteStoreType
                                                 configuration:nil
                                                           URL:localStore
                                                       options:options
                                                         error:nil];
        [persistentStoreCoordinator unlock];
        
    }
    
    dispatch_async(dispatch_get_main_queue(), ^{
        [[NSNotificationCenter defaultCenter] postNotificationName:@"SomethingChanged" object:self userInfo:nil];
    });
    //    });
    
    return _persistentStoreCoordinator;
}

#pragma mark -
#pragma mark - Application's Documents directory

// Returns the URL to the application's Documents directory.
- (NSURL *) applicationDocumentsDirectory
{
    return [[[NSFileManager defaultManager] URLsForDirectory:NSDocumentDirectory inDomains:NSUserDomainMask] lastObject];
}

@end
