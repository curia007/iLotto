//
//  MegaMillions.m
//  SampleLotto
//
//  Created by Carmelo I. Uria on 6/28/13.
//  Copyright (c) 2013 Carmelo Uria Corporation. All rights reserved.
//

#import "MegaMillions.h"


@implementation MegaMillions

@dynamic date;
@dynamic lottoNumber;
@dynamic wb1;
@dynamic wb2;
@dynamic wb3;
@dynamic wb4;
@dynamic wb5;
@dynamic mb;

@end
