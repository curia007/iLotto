//
//  FutureTicket.h
//  iLotto
//
//  Created by Carmelo I. Uria on 8/5/13.
//  Copyright (c) 2013 Carmelo Uria Corporation. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>


@interface FutureTicket : NSManagedObject

@property (nonatomic, retain) NSString * date;
@property (nonatomic, retain) NSNumber * moneyball;
@property (nonatomic, retain) NSString * type;
@property (nonatomic, retain) id whiteballs;
@property (nonatomic, retain) NSManagedObject *game;

@end
