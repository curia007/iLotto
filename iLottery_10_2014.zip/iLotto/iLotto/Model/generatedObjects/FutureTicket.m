//
//  FutureTicket.m
//  iLotto
//
//  Created by Carmelo I. Uria on 8/5/13.
//  Copyright (c) 2013 Carmelo Uria Corporation. All rights reserved.
//

#import "FutureTicket.h"


@implementation FutureTicket

@dynamic date;
@dynamic moneyball;
@dynamic type;
@dynamic whiteballs;
@dynamic game;

@end
