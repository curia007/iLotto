//
//  ModelManager.h
//  SampleLotto
//
//  Created by Carmelo I. Uria on 7/24/13.
//  Copyright (c) 2013 Carmelo Uria Corporation. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "LottoProcessor.h"

@class MegaMillions;
@class FutureTicket;
@class WinningTicket;
@class LotteryResultsGame;

@protocol ModelManagerDelegate;

@interface ModelManager : NSObject

@property id <ModelManagerDelegate> delegate;

- (NSManagedObjectContext *) managedObjectContext;
- (NSManagedObjectModel *) managedObjectModel;
- (NSPersistentStoreCoordinator *) persistentStoreCoordinator;

- (void) removeMegaMillionsInformation;
- (BOOL) isMegaMillionsInformationExistsWithDate:(NSString *) date;
- (BOOL) isFutureGameExistWithDate:(NSString *) date;
- (NSArray *) retrieveMegaMillions;

- (void) removePowerballInformation;
- (BOOL) isPowerballInformationExistsWithDate:(NSString *) date;
- (NSArray *) retrievePowerball;

- (void) addFrequencyWithNumber:(NSInteger) lottoNumber moneyBall:(BOOL) isMoneyBall lottoType:(LottoType) lottoType;

- (NSArray *) retrieveFrequencyWithSortDescriptor:(NSSortDescriptor *) sortDescriptor lottoType:(LottoType) lottoType;
- (NSArray *) retrieveFrequencyWithSortDescriptors:(NSArray *) sortDescriptors;

- (NSArray *) retrieveFutureGameWithDate:(NSString *) date;
- (NSArray *) retrieveFutureTicketsWithDate:(NSString *) date;

- (void) insertFutureTicketWithWinningTickets:(NSArray *) winningTickets;
- (void) insertFutureTicketWithLottoType:(LottoType) lottoType date:(NSString *) date numbers:(NSArray *) numbers moneyball:(NSInteger) moneyball;
- (void) updateFutureTicketWithLottoType:(LottoType) lottoType date:(NSString *) date numbers:(NSArray *) numbers moneyball:(NSInteger) moneyball;

- (void) processWinningGameWithLottoType:(LottoType) lottoType tickets:(NSArray *) winningTickets date:(NSString *) date;
- (void) processWithLotteryResultsGame:(LotteryResultsGame *) lotteryResultsGame;

@end

@protocol ModelManagerDelegate <NSObject>

- (void) modelManagerDidFinish:(ModelManager *) modelManager results:(id) results;
- (void) modelManager:(ModelManager *) modelManager didFailWithError:(NSError *) error;

@end