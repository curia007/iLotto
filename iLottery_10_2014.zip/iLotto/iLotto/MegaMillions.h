//
//  MegaMillions.h
//  iLotto
//
//  Created by Carmelo I. Uria on 7/25/13.
//  Copyright (c) 2013 Carmelo Uria Corporation. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>


@interface MegaMillions : NSManagedObject

@property (nonatomic, retain) NSString * date;
@property (nonatomic, retain) NSNumber * lottoNumber;
@property (nonatomic, retain) NSNumber * mb;
@property (nonatomic, retain) NSNumber * wb1;
@property (nonatomic, retain) NSNumber * wb2;
@property (nonatomic, retain) NSNumber * wb3;
@property (nonatomic, retain) NSNumber * wb4;
@property (nonatomic, retain) NSNumber * wb5;

@end
