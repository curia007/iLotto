//
//  AppDelegate.h
//  iLotto
//
//  Created by Carmelo I. Uria on 7/24/13.
//  Copyright (c) 2013 Carmelo Uria Corporation. All rights reserved.
//

#import <UIKit/UIKit.h>

@class USLotteryFeedReader;
@class PowerballProcessor;
@class MegaMillionsProcessor;

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) USLotteryFeedReader *feedReader;
@property (strong, nonatomic, readonly) PowerballProcessor *powerballProcessor;
@property (strong, nonatomic, readonly) MegaMillionsProcessor *megaMillionsProcessor;

@end
