//
//  Lottery.m
//  iLotto
//
//  Created by Carmelo I. Uria on 12/22/13.
//  Copyright (c) 2013 Carmelo Uria Corporation. All rights reserved.
//

#import "Lottery.h"

NSString *LotteryResultsNotification = @"LotteryResultsNotification";

@implementation Lottery

@end
