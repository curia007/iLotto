//
//  Vocializer.m
//  iTranslator
//
//  Created by Carmelo I. Uria on 12/8/13.
//  Copyright (c) 2013 Carmelo I. Uria. All rights reserved.
//

#import "Vocializer.h"

@interface Vocializer ()

@property (nonatomic, strong) SKVocalizer *vocializer;

@end

@implementation Vocializer

- (id) initWithVoice:(NSString *) voice
{
    self = [super init];
    
    if (self != nil)
    {
        _vocializer = [[SKVocalizer alloc] initWithVoice:voice delegate:self];
        _voice = voice;
    }
    
    return self;
}

- (id) initWithLanguage:(NSString *) language
{
    self = [super init];
    
    if (self != nil)
    {
        _vocializer = [[SKVocalizer alloc] initWithLanguage:language delegate:self];
        _language = language;
    }
    
    return self;
}

- (void) speakWithText:(NSString *) text
{
    [[self vocializer] speakString:text];
}

#pragma mark -
#pragma mark SKVocalizerDelegate methods

- (void) vocalizer:(SKVocalizer *) vocalizer willBeginSpeakingString:(NSString *) text
{
    NSLog(@"Vocializer begnin speaking...");
}

- (void) vocalizer:(SKVocalizer *) vocalizer willSpeakTextAtCharacter:(NSUInteger) index ofString:(NSString *) text
{
    
    //NSLog(@"Session id [%@].", [SpeechKit sessionID]); // for debugging purpose: printing out the speechkit session id

}

- (void) vocalizer:(SKVocalizer *) vocalizer didFinishSpeakingString:(NSString *) text withError:(NSError *) error
{
    NSLog(@"Did finish speaking: Session id [%@].", [SpeechKit sessionID]); // for debugging purpose: printing out the speechkit session id
}

@end
