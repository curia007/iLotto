//
//  Vocializer.h
//  iTranslator
//
//  Created by Carmelo I. Uria on 12/8/13.
//  Copyright (c) 2013 Carmelo I. Uria. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <SpeechKit/SpeechKit.h>

@interface Vocializer : NSObject <SKVocalizerDelegate>

@property (nonatomic, readonly) NSString *language;
@property (nonatomic, readonly) NSString *voice;

- (id) initWithVoice:(NSString *) voice;
- (id) initWithLanguage:(NSString *) language;

- (void) speakWithText:(NSString *) text;

@end
