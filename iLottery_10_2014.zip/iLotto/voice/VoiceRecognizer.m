//
//  VoiceRecognizer.m
//  iTranslator
//
//  Created by Carmelo I. Uria on 12/8/13.
//  Copyright (c) 2013 Carmelo I. Uria. All rights reserved.
//

#import "VoiceRecognizer.h"

/**
 * The login parameters should be specified in the following manner:
 */
const unsigned char SpeechKitApplicationKey[] = {0x3a, 0x1f, 0x35, 0xf3, 0x43, 0x92, 0xb6, 0x40, 0xc4, 0x28, 0x76, 0x66, 0x53, 0x96, 0x14, 0xb7, 0x3d, 0x55, 0x6c, 0x98, 0xe1, 0x96, 0xb0, 0xe2, 0xdd, 0x50, 0xd, 0xd, 0xb4, 0xa8, 0x53, 0xef, 0xc8, 0x88, 0xe2, 0xb, 0x1b, 0x99, 0x4b, 0xdf, 0xc1, 0xc2, 0x45, 0x14, 0x58, 0x59, 0xcb, 0x95, 0xaf, 0x38, 0x2e, 0x90, 0xce, 0xde, 0x72, 0xac, 0x2e, 0x7f, 0xb9, 0xe3, 0x28, 0xc, 0xd2, 0xf0};
/*
 * Please note that all the specified values are non-functional
 * and are provided solely as an illustrative example.
 *
 */

@interface VoiceRecognizer ()

@property (nonatomic, strong) SKRecognizer *voiceSearch;
@property (nonatomic, strong) id<SKRecognizerDelegate> recognizerDelegate;

@end

@implementation VoiceRecognizer

- (id) initWithRecognizerDelegate:(id<SKRecognizerDelegate>) delegate locale:(NSLocale *) locale
{
    self = [super init];
    
    if (self != nil)
    {
        _originatingLanguage = locale;
        _recognizerDelegate = delegate;
    }
    
    return self;
}

- (void) record
{
    SKEndOfSpeechDetection detectionType;
    NSString *dictationRecognizerType;
        
    /* 'Dictation' is selected */
    detectionType = SKLongEndOfSpeechDetection; /* Dictations tend to be long utterances that may include short pauses. */
    //detectionType = SKShortEndOfSpeechDetection;
    dictationRecognizerType = SKDictationRecognizerType; /* Optimize recognition performance for dictation or message text. */
    
    /* Nuance can also create a custom recognition type optimized for your application if neither search nor dictation are appropriate. */
    NSString *localeIdentifier = [[self originatingLanguage] localeIdentifier];
    NSLog(@"Recognizing type:'%@' Language Code: '%@' using end-of-speech detection:%lu.", dictationRecognizerType, localeIdentifier, (unsigned long)detectionType);
    
    if ([self voiceSearch] != nil)
    {
        [self setVoiceSearch:nil];
    }
    
    _voiceSearch = [[SKRecognizer alloc] initWithType:dictationRecognizerType
                                            detection:detectionType
                                             language:localeIdentifier
                                             delegate:[self recognizerDelegate]];
}

- (void) dealloc
{
    [SpeechKit destroy];
}

@end
