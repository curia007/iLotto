//
//  VoiceRecognizer.h
//  iTranslator
//
//  Created by Carmelo I. Uria on 12/8/13.
//  Copyright (c) 2013 Carmelo I. Uria. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <SpeechKit/SpeechKit.h>

@interface VoiceRecognizer : NSObject

@property (nonatomic, strong) NSLocale *originatingLanguage;

- (id) initWithRecognizerDelegate:(id<SKRecognizerDelegate>) translator locale:(NSLocale *) locale;
- (void) record;

@end
