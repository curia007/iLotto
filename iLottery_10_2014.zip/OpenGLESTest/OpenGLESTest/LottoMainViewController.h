//
//  ViewController.h
//  OpenGLESTest
//
//  Created by Carmelo I. Uria on 5/17/13.
//  Copyright (c) 2013 Carmelo Uria Corporation. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <GLKit/GLKit.h>

#import <JATicker.h>

@interface LottoMainViewController : GLKViewController
@property (weak, nonatomic) IBOutlet JATickerView *megaMillionsTickerView;

@end
