//
//  AppDelegate.h
//  OpenGLESTest
//
//  Created by Carmelo I. Uria on 5/17/13.
//  Copyright (c) 2013 Carmelo Uria Corporation. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
