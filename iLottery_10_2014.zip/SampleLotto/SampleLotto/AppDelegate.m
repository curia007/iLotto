//
//  AppDelegate.m
//  SampleLotto
//
//  Created by Carmelo I. Uria on 5/1/13.
//  Copyright (c) 2013 Carmelo Uria Corporation. All rights reserved.
//

#import "AppDelegate.h"

#import "LotteryResultsGame.h"

#import "PowerballProcessor.h"
#import "MegaMillionsProcessor.h"

@interface AppDelegate ()

@property (nonatomic, strong) PowerballProcessor *powerballProcessor;
@property (nonatomic, strong) MegaMillionsProcessor *megaMillionsProcessor;

@property (nonatomic, strong) USLotteryFeedReader *feedReader;

- (NSString *) stringWithDate:(NSDate *) date;

@end

@implementation AppDelegate

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{
    // Override point for customization after application launch.

    [application setApplicationIconBadgeNumber:0];

//    NSTimeInterval timeInterval = 5184000.0; //24 hours
//    NSTimeInterval timeInterval = 601.0f;
//    
//    [application setKeepAliveTimeout:timeInterval handler:^{
//    
//        if ([self feedReader] == nil)
//        {
//            _feedReader = [[USLotteryFeedReader alloc] init];
//        }
//        
//        [[self feedReader] setDelegate:self];
//        
//        [[self feedReader] processResults];
//
//    }];
    
    _powerballProcessor = [[PowerballProcessor alloc] init];
    [[self powerballProcessor] processLottoNumbers];
    _megaMillionsProcessor = [[MegaMillionsProcessor alloc] init];
    [[self megaMillionsProcessor] processLottoNumbers];
    
    return YES;
}
							
- (void)applicationWillResignActive:(UIApplication *)application
{
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
}

- (void)applicationDidEnterBackground:(UIApplication *)application
{
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later. 
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}

- (void)applicationWillEnterForeground:(UIApplication *)application
{
    // Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
}

- (void)applicationDidBecomeActive:(UIApplication *)application
{
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
}

- (void)applicationWillTerminate:(UIApplication *)application
{
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}

- (void) application:(UIApplication *) application didReceiveLocalNotification:(UILocalNotification *) notification
{
    NSLog(@"Local Notification was received...");
}

- (NSString *) stringWithDate:(NSDate *) date
{
    return nil;
}

#pragma mark -
#pragma mark - USlotteryFeedReaderDelegate methods

- (void) lotteryFeedReader:(USLotteryFeedReader *) reader completedWithError:(NSError *) error
{
    
}

- (void) lotteryFeedReader:(USLotteryFeedReader *) reader completedWithResults:(NSArray *) results
{
    NSString *sound = @"money.mp3";
    NSMutableString *alertBody = [NSMutableString string];
    UILocalNotification *resultsNotification = [[UILocalNotification alloc] init];
    
    PowerballProcessor *powerballProcessor = [[PowerballProcessor alloc] init];
    
    [resultsNotification setFireDate:[NSDate date]];
    
    [resultsNotification setSoundName:sound];
    [resultsNotification setAlertBody:alertBody];

    NSUInteger count = [[UIApplication sharedApplication] applicationIconBadgeNumber];
    count = count + [results count];
    
    [resultsNotification setApplicationIconBadgeNumber:count];

    [results enumerateObjectsUsingBlock:^(LotteryResultsGame *gameResults, NSUInteger idx, BOOL *stop) {
        NSLog(@"results : %@", gameResults);
        
        [powerballProcessor processLatestLottoNumber:gameResults];
        
        NSString *stringResults = [NSString stringWithFormat:@"%@ : %@/n/n%@", [gameResults name], [self stringWithDate:[gameResults date]], [gameResults information]];
        
        [alertBody appendFormat:@"%@/n/n", stringResults];
    }];
    
    [resultsNotification setAlertBody:alertBody];
    [[UIApplication sharedApplication] presentLocalNotificationNow:resultsNotification];
}

@end
