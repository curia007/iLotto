//
//  MegaMillionsProcessor.h
//  SampleLotto
//
//  Created by Carmelo I. Uria on 6/28/13.
//  Copyright (c) 2013 Carmelo Uria Corporation. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MegaMillionsProcessor : NSObject

- (void) processLottoNumbers;
- (NSSet *) retrieveNextWinningGamesWithMegaMillionsHistory:(NSArray *) megaMillions count:(NSInteger) ticketCount;

@end
