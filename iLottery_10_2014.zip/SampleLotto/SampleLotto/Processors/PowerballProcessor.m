//
//  PowerballProcessor.m
//  SampleLotto
//
//  Created by Carmelo I. Uria on 5/19/13.
//  Copyright (c) 2013 Carmelo Uria Corporation. All rights reserved.
//
//  http://www.powerball.com/powerball/winnums-text.txt

#import "PowerballProcessor.h"

#import "PowerballIncrementalStore.h"
#import "Powerball.h"

#import "LotteryResultsGame.h"

#define kLocalStoreFilename @"LottoModel.sqlite"
#define POWERBALL_NUMBERS_URL_STRING @"http://www.powerball.com/powerball/winnums-text.txt"

@interface PowerballProcessor ()

@property (nonatomic, strong) NSManagedObjectContext *managedObjectContext;
@property (nonatomic, strong) NSManagedObjectContext *lottoWebServiceManagedObjectContext;

@property (nonatomic, strong) NSManagedObjectModel *managedObjectModel;
@property (nonatomic, strong) NSPersistentStoreCoordinator *persistentStoreCoordinator;
@property (nonatomic, strong) NSOperationQueue *queue;

- (void) processGame:(NSString *) gameInformation;

@end

@implementation PowerballProcessor

- (NSManagedObjectContext *) lottoWebServiceManagedObjectContext
{
    
    NSManagedObjectModel* model = [self managedObjectModel];
    
    [NSPersistentStoreCoordinator registerStoreClass:[PowerballIncrementalStore class] forStoreType:@"PowerballIncrementalStore"];
    NSPersistentStoreCoordinator* coordinator = [[NSPersistentStoreCoordinator alloc] initWithManagedObjectModel:model];
    
    NSError* error = nil;
    
    [coordinator addPersistentStoreWithType:@"PowerballIncrementalStore" configuration:nil URL:nil options:nil error:&error];
    
    if (_lottoWebServiceManagedObjectContext == nil)
    {
        _lottoWebServiceManagedObjectContext = [[NSManagedObjectContext alloc] init];
        [_lottoWebServiceManagedObjectContext setPersistentStoreCoordinator:coordinator];
    }
    
    return _lottoWebServiceManagedObjectContext;
}

- (void) processLatestLottoNumber:(LotteryResultsGame *) game
{
    if ([self hasPowerballNumbers] == NO)
    {
        [self processLottoNumbers];
    }
    else
    {
        if (game != nil)
        {
            NSLog(@"Add results to database");
        }
        else
        {
            NSError *error = nil;
            NSManagedObjectContext *managedObjectContext = [self lottoWebServiceManagedObjectContext];
            NSFetchRequest *fetchRequest = [[self managedObjectModel] fetchRequestTemplateForName:@"PowerballFetchRequest"];
            NSArray *results = [managedObjectContext executeFetchRequest:fetchRequest error:&error];
            NSLog(@"Test");
        }
    }
}

- (void) processLottoNumbers
{

    // check if database is empty
    if ([self hasPowerballNumbers] == YES)
    {
        return;
    }
    
    if ([self queue] == nil)
    {
        _queue = [NSOperationQueue currentQueue];
    }
    
    NSURL *URL = [NSURL URLWithString:POWERBALL_NUMBERS_URL_STRING];
    NSURLRequest *request = [NSURLRequest requestWithURL:URL];
    [NSURLConnection sendAsynchronousRequest:request queue:[self queue] completionHandler:^(NSURLResponse *response, NSData *data, NSError *error)
    {
        NSString *string = [NSString stringWithUTF8String:[data bytes]];
        
        NSArray *lines = [string componentsSeparatedByCharactersInSet:[NSCharacterSet newlineCharacterSet]];
        NSMutableArray *array = [NSMutableArray arrayWithArray:lines];
        [array removeObjectAtIndex:0];
        lines = [NSArray arrayWithArray:array];
        array = nil;
        
        [lines enumerateObjectsUsingBlock:^(NSString *line, NSUInteger idx, BOOL *stop) {
            [self processGame:line];
        }];
    }];
}

- (BOOL) hasPowerballNumbers
{
    NSManagedObjectModel *model = [self managedObjectModel];
    NSFetchRequest *fetchRequest = [model fetchRequestTemplateForName:@"PowerballFetchRequest"];
    
    NSError *error = nil;
    
    NSArray *gameResults = [[self managedObjectContext] executeFetchRequest:fetchRequest error:&error];
    
    if ([gameResults count] > 0)
    {
        return YES;
    }
    
    return NO;
}

- (void) processGame:(NSString *) gameInformation
{
    if ((gameInformation == nil) | ([gameInformation length] == 0))
    {
        return;
    }
    
    NSLog(@"game information : %@", gameInformation);
    NSArray *elements = [gameInformation componentsSeparatedByCharactersInSet:[NSCharacterSet whitespaceCharacterSet]];

    NSMutableArray *items = [NSMutableArray arrayWithCapacity:1];
    [elements enumerateObjectsUsingBlock:^(NSString *element, NSUInteger idx, BOOL *stop) {
        if ([element length]!= 0)
        {
            [items addObject:element];
        }
    }];
    
//    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
//    [dateFormatter setDateFormat:@"MM/dd/YYY"];
//    NSDate *date = [dateFormatter dateFromString:[items objectAtIndex:0]];
    
    Powerball *powerballEntity = (Powerball *)[NSEntityDescription insertNewObjectForEntityForName:@"Powerball" inManagedObjectContext:[self managedObjectContext]];
    
    NSError *error = nil;
    
    [powerballEntity setDate:[items objectAtIndex:0]];
    
    [powerballEntity setWb1:[NSNumber numberWithInteger:[[items objectAtIndex:1] integerValue]]];
    [powerballEntity setWb2:[NSNumber numberWithInteger:[[items objectAtIndex:2] integerValue]]];
    [powerballEntity setWb3:[NSNumber numberWithInteger:[[items objectAtIndex:3] integerValue]]];
    [powerballEntity setWb4:[NSNumber numberWithInteger:[[items objectAtIndex:4] integerValue]]];
    [powerballEntity setWb5:[NSNumber numberWithInteger:[[items objectAtIndex:5] integerValue]]];
    [powerballEntity setPb:[NSNumber numberWithInteger:[[items objectAtIndex:6] integerValue]]];
    
    if ([items count] == 8)
    {
        [powerballEntity setPp:[NSNumber numberWithInteger:[[items objectAtIndex:7] integerValue]]];
    }
    
    [[self managedObjectContext] save:&error];
}

#pragma mark
#pragma mark - Core Data stack

// Returns the managed object context for the application.
// If the context doesn't already exist, it is created and bound to the persistent store coordinator for the application.
- (NSManagedObjectContext *) managedObjectContext
{
    if (_managedObjectContext != nil)
    {
        return _managedObjectContext;
    }
    
    NSPersistentStoreCoordinator *coordinator = [self persistentStoreCoordinator];
    if (coordinator != nil)
    {
        _managedObjectContext = [[NSManagedObjectContext alloc] init];
        [_managedObjectContext setPersistentStoreCoordinator:coordinator];
    }
    return _managedObjectContext;
}

// Returns the managed object model for the application.
// If the model doesn't already exist, it is created from the application's model.
- (NSManagedObjectModel *) managedObjectModel
{
    if (_managedObjectModel != nil)
    {
        return _managedObjectModel;
    }
    
    NSURL *modelURL = [[NSBundle mainBundle] URLForResource:@"LottoModel" withExtension:@"momd"];
    _managedObjectModel = [[NSManagedObjectModel alloc] initWithContentsOfURL:modelURL];
    
    return _managedObjectModel;
}

// Returns the persistent store coordinator for the application.
// If the coordinator doesn't already exist, it is created and the application's store added to it.
- (NSPersistentStoreCoordinator *) persistentStoreCoordinator
{
    if (_persistentStoreCoordinator != nil)
    {
        return _persistentStoreCoordinator;
    }
    
    NSURL *storeURL = [[self applicationDocumentsDirectory] URLByAppendingPathComponent:kLocalStoreFilename];
    
    NSError *error = nil;
    _persistentStoreCoordinator = [[NSPersistentStoreCoordinator alloc] initWithManagedObjectModel:[self managedObjectModel]];
    if (![_persistentStoreCoordinator addPersistentStoreWithType:NSSQLiteStoreType configuration:nil URL:storeURL options:nil error:&error])
    {
        /*
         Replace this implementation with code to handle the error appropriately.
         
         abort() causes the application to generate a crash log and terminate. You should not use this function in a shipping application, although it may be useful during development.
         
         Typical reasons for an error here include:
         * The persistent store is not accessible;
         * The schema for the persistent store is incompatible with current managed object model.
         Check the error message to determine what the actual problem was.
         
         
         If the persistent store is not accessible, there is typically something wrong with the file path. Often, a file URL is pointing into the application's resources directory instead of a writeable directory.
         
         If you encounter schema incompatibility errors during development, you can reduce their frequency by:
         * Simply deleting the existing store:
         [[NSFileManager defaultManager] removeItemAtURL:storeURL error:nil]
         
         * Performing automatic lightweight migration by passing the following dictionary as the options parameter:
         @{NSMigratePersistentStoresAutomaticallyOption:@YES, NSInferMappingModelAutomaticallyOption:@YES}
         
         Lightweight migration will only work for a limited set of schema changes; consult "Core Data Model Versioning and Data Migration Programming Guide" for details.
         
         */
        NSLog(@"Unresolved error %@, %@", error, [error userInfo]);
        abort();
    }
    
    return _persistentStoreCoordinator;
}

#pragma mark -
#pragma mark - Application's Documents directory

// Returns the URL to the application's Documents directory.
- (NSURL *) applicationDocumentsDirectory
{
    return [[[NSFileManager defaultManager] URLsForDirectory:NSDocumentDirectory inDomains:NSUserDomainMask] lastObject];
}

@end
