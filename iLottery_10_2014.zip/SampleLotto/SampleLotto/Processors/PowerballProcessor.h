//
//  PowerballProcessor.h
//  SampleLotto
//
//  Created by Carmelo I. Uria on 5/19/13.
//  Copyright (c) 2013 Carmelo Uria Corporation. All rights reserved.
//

#import <Foundation/Foundation.h>

@class LotteryResultsGame;

@interface PowerballProcessor : NSObject

- (NSManagedObjectContext *) lottoWebServiceManagedObjectContext;

- (void) processLottoNumbers;
- (void) processLatestLottoNumber:(LotteryResultsGame *) game;

- (BOOL) hasPowerballNumbers;

@end
