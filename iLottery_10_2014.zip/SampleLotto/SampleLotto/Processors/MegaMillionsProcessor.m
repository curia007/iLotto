//
//  MegaMillionsProcessor.m
//  SampleLotto
//
//  Created by Carmelo I. Uria on 6/28/13.
//  Copyright (c) 2013 Carmelo Uria Corporation. All rights reserved.
//

#import "MegaMillionsProcessor.h"

#import "ModelManager.h"

#import "LotteryResultsGame.h"
#import "MegaMillions.h"

#define MEGAMILLIONS_NUMBERS_URL_STRING @"http://www.calottery.com/sitecore/content/Miscellaneous/download-numbers/?GameName=mega-millions"

@interface MegaMillionsProcessor ()

@property (nonatomic, strong) ModelManager *modelManager;
@property (nonatomic, strong) NSOperationQueue *queue;

@end

@implementation MegaMillionsProcessor

- (void) processLottoNumbers
{
    
    if ([self queue] == nil)
    {
        _queue = [NSOperationQueue currentQueue];
    }
    
    if ([self modelManager] == nil)
    {
        _modelManager = [[ModelManager alloc] init];
    }
    
    NSURL *URL = [NSURL URLWithString:MEGAMILLIONS_NUMBERS_URL_STRING];
    NSURLRequest *request = [NSURLRequest requestWithURL:URL];
    
    [NSURLConnection sendAsynchronousRequest:request queue:[self queue] completionHandler:^(NSURLResponse *response, NSData *data, NSError *error)
     {
         NSString* string = nil;
         string = [[NSString alloc] initWithData:data encoding:NSASCIIStringEncoding];
         
         NSArray *lines = [string componentsSeparatedByCharactersInSet:[NSCharacterSet newlineCharacterSet]];
         NSMutableArray *array = [NSMutableArray arrayWithArray:lines];
         
         NSRange range;
         range.location = 0;
         range.length = 9;
         
         NSIndexSet *indexes = [NSIndexSet indexSetWithIndexesInRange:range];

         [array removeObjectsAtIndexes:indexes];
         
         lines = [NSArray arrayWithArray:array];
         array = nil;
         
         [lines enumerateObjectsUsingBlock:^(NSString *line, NSUInteger idx, BOOL *stop) {
             [self processGame:line];
         }];
     }];
}

- (void) processGame:(NSString *) gameInformation
{
    if ((gameInformation == nil) | ([gameInformation length] == 0))
    {
        return;
    }
    
    NSLog(@"game information : %@", gameInformation);
    NSArray *elements = [gameInformation componentsSeparatedByCharactersInSet:[NSCharacterSet whitespaceCharacterSet]];
    
    NSMutableArray *items = [NSMutableArray arrayWithCapacity:1];
    [elements enumerateObjectsUsingBlock:^(NSString *element, NSUInteger idx, BOOL *stop) {
        if ([element length]!= 0)
        {
            [items addObject:element];
        }
    }];
    
    NSString *date = [NSString stringWithFormat:@"%@ %@%@ %@", [items objectAtIndex:1], [items objectAtIndex:2], [items objectAtIndex:3], [items objectAtIndex:4]];

    BOOL isMegaMillionsGameExist = [[self modelManager] isMegaMillionsInformationExistsWithDate:date];
    
    if (isMegaMillionsGameExist == YES)
    {
        return;
    }
    
    MegaMillions *megaMillionsEntity = (MegaMillions *)[NSEntityDescription insertNewObjectForEntityForName:@"MegaMillions" inManagedObjectContext:[[self modelManager] managedObjectContext]];
    
    NSError *error = nil;
    
    [megaMillionsEntity setLottoNumber:[NSNumber numberWithInt:[[items objectAtIndex:0] integerValue]]];
    [megaMillionsEntity setDate:date];
    
    [megaMillionsEntity setWb1:[NSNumber numberWithInteger:[[items objectAtIndex:5] integerValue]]];
    [megaMillionsEntity setWb2:[NSNumber numberWithInteger:[[items objectAtIndex:6] integerValue]]];
    [megaMillionsEntity setWb3:[NSNumber numberWithInteger:[[items objectAtIndex:7] integerValue]]];
    [megaMillionsEntity setWb4:[NSNumber numberWithInteger:[[items objectAtIndex:8] integerValue]]];
    [megaMillionsEntity setWb5:[NSNumber numberWithInteger:[[items objectAtIndex:9] integerValue]]];
    [megaMillionsEntity setMb:[NSNumber numberWithInteger:[[items objectAtIndex:10] integerValue]]];
    
    
    [[[self modelManager] managedObjectContext] save:&error];
}

- (NSSet *) retrieveNextWinningGamesWithMegaMillionsHistory:(NSArray *) megaMillions count:(NSInteger) ticketCount
{
    NSSet *winners = nil;
    
    NSArray *games = [[self modelManager] retrieveMegaMillions];
    
    if ([games count] == 0)
    {
        return nil;
    }
    
    
    return winners;
}

@end
