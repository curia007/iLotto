//
//  ImageViewController.h
//  SampleLotto
//
//  Created by Carmelo I. Uria on 5/1/13.
//  Copyright (c) 2013 Carmelo Uria Corporation. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface ImageViewController : UIViewController

@property (weak, nonatomic) IBOutlet UIImageView *imageView;

@end
