//
//  ModelManager.h
//  SampleLotto
//
//  Created by Carmelo I. Uria on 7/24/13.
//  Copyright (c) 2013 Carmelo Uria Corporation. All rights reserved.
//

#import <Foundation/Foundation.h>

@class MegaMillions;

@protocol ModelManagerDelegate;

@interface ModelManager : NSObject

@property id <ModelManagerDelegate> delegate;

- (NSManagedObjectContext *) managedObjectContext;
- (NSManagedObjectModel *) managedObjectModel;
- (NSPersistentStoreCoordinator *) persistentStoreCoordinator;

- (void) removeMegaMillionsInformation;
- (BOOL) isMegaMillionsInformationExistsWithDate:(NSString *) date;
- (NSArray *) retrieveMegaMillions;

- (void) removePowerballInformation;
- (BOOL) isPowerballInformationExistsWithDate:(NSString *) date;
- (NSArray *) retrievePowerball;

@end

@protocol ModelManagerDelegate <NSObject>

- (void) modelManagerDidFinish:(ModelManager *) modelManager results:(id) results;
- (void) modelManager:(ModelManager *) modelManager didFailWithError:(NSError *) error;

@end