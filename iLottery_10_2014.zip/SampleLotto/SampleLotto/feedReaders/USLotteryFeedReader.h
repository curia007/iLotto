//
//  USLotteryFeedReader.h
//  SampleLotto
//
//  Created by Carmelo I. Uria on 5/3/13.
//  Copyright (c) 2013 Carmelo Uria Corporation. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "USLotteryFeedProcessor.h"

@class USLotteryFeedReader;

@protocol USlotteryFeedReaderDelegate <NSObject>

- (void) lotteryFeedReader:(USLotteryFeedReader *) reader completedWithError:(NSError *) error;
- (void) lotteryFeedReader:(USLotteryFeedReader *) reader completedWithResults:(NSArray *) results;

@end

@interface USLotteryFeedReader : NSObject <USlotteryFeedProcessorDelegate>

@property (nonatomic, assign) id<USlotteryFeedReaderDelegate> delegate;

- (void) processResults;

@end
