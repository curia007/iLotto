//
//  ImageViewController.m
//  SampleLotto
//
//  Created by Carmelo I. Uria on 5/1/13.
//  Copyright (c) 2013 Carmelo Uria Corporation. All rights reserved.
//

#import "ImageViewController.h"
#import "PowerballProcessor.h"

@interface ImageViewController ()

@property (nonatomic, strong) PowerballProcessor *processor;

@end

@implementation ImageViewController

- (id) initWithNibName:(NSString *) nibNameOrNil bundle:(NSBundle *) nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self)
    {
        // Custom initialization
    }
    return self;
}

- (void) viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
    _processor = [[PowerballProcessor alloc] init];
    [[self processor] processLatestLottoNumber:nil];
    
//    CATransform3D transform = CATransform3DIdentity;
//    transform.m34 = -1 / 500.0;
//    transform = CATransform3DRotate(transform, .85 * M_PI_2, 1, 0, 0);
//    self.imageView.layer.transform = transform;
    
//    UIImageView *imageView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"lotto_ball.gif"]];
//    CALayer *lottoLayer = [imageView layer];
//    [lottoLayer setValue:[NSNumber numberWithInt:5] forKey:@"transform.scale"];
    
//    [self.imageView.layer addSublayer:lottoLayer];
//    CGRect frame = self.imageView.layer.frame;
//    CGPoint point = self.imageView.layer.anchorPoint;
    
    //    frame.origin = point;
   
}

- (void) viewDidAppear:(BOOL) animated
{
    [super viewDidAppear:animated];

    CGPoint point = CGPointMake(-5.0f, 30.0f);
    CGRect frame = CGRectMake(0.0f, 0.0f, 120.0f, 120.0f);
    frame.origin = point;
    
    CATextLayer *label = [[CATextLayer alloc] init];
 
    [label setFont:@"Helvetica-Bold"];
    [label setFontSize:40];

    [label setFrame:frame];
    [label setString:@"7"];
    [label setAlignmentMode:kCAAlignmentCenter];
    [label setForegroundColor:[[UIColor blackColor] CGColor]];
    
    [self.imageView.layer addSublayer:label];

    [UIView animateWithDuration:10.0
                          delay:1.0
                        options:UIViewAnimationCurveEaseOut
                     animations:^{
//        CAKeyframeAnimation* widthAnim = [CAKeyframeAnimation
//                                          animationWithKeyPath:@"borderWidth"];
//        NSArray* widthValues = [NSArray arrayWithObjects:@1.0, @10.0, @5.0, @30.0, @0.5,
//                                @15.0, @2.0, @50.0, @0.0, nil];
//        widthAnim.values = widthValues;
//        widthAnim.calculationMode = kCAAnimationPaced;
//        // Animation 2
//        CAKeyframeAnimation* colorAnim = [CAKeyframeAnimation
//                                          animationWithKeyPath:@"borderColor"];
//        NSArray* colorValues = [NSArray arrayWithObjects:(id)[UIColor greenColor].CGColor, (id)[UIColor redColor].CGColor, (id)[UIColor blueColor].CGColor, nil];
//        colorAnim.values = colorValues;
//        colorAnim.calculationMode = kCAAnimationPaced;
//        
//        //[self.imageView.layer addAnimation:widthAnim forKey:@"borderWidth"];
//        //[self.imageView.layer addAnimation:colorAnim forKey:@"borderColor"];
//        
        CABasicAnimation *animation = [CABasicAnimation animationWithKeyPath:@"transform.rotation"];
        animation.fromValue = [NSNumber numberWithFloat:0];
        animation.toValue = [NSNumber numberWithFloat:2 * M_PI];
        animation.duration = 1.1;
        animation.repeatCount = HUGE_VALF;
        animation.timingFunction = [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionLinear];
        [self.imageView.layer addAnimation:animation forKey:@"transform.rotation"];
        
        // Animation group
//        CAAnimationGroup* group = [CAAnimationGroup animation];
//        group.animations = [NSArray arrayWithObjects:colorAnim, widthAnim, nil];
//        group.duration = 5.0;
//        [self.imageView.layer addAnimation:group forKey:@"BorderChanges"];
        
        CGRect rect = CGRectMake(0.0f, 0.0f, 120.0f, 140.0f);
        UIBezierPath *path = [UIBezierPath bezierPathWithOvalInRect:rect];
    
        CAKeyframeAnimation *anim = [CAKeyframeAnimation animationWithKeyPath:@"position"];
        anim.path = path.CGPath;
        anim.rotationMode = kCAAnimationRotateAuto;
        anim.repeatCount = HUGE_VALF;
        anim.duration = 8.0;
        [self.imageView.layer addAnimation:anim forKey:@"path"];

    }
     completion:^(BOOL finished) {
         NSLog(@"Animations Completed...");
    }];
}

- (void) didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
