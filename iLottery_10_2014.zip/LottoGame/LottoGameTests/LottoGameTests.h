//
//  LottoGameTests.h
//  LottoGameTests
//
//  Created by Carmelo I. Uria on 5/1/13.
//  Copyright (c) 2013 Carmelo Uria Corporation. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface LottoGameTests : SenTestCase

@end
