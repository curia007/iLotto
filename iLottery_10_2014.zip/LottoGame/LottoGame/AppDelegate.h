//
//  AppDelegate.h
//  LottoGame
//
//  Created by Carmelo I. Uria on 5/1/13.
//  Copyright (c) 2013 Carmelo Uria Corporation. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
