//
//  AppDelegate.h
//  RagsToRiches
//
//  Created by Carmelo I. Uria on 5/18/14.
//  Copyright (c) 2014 Carmelo Uria Corporation. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
