//
//  ViewController.m
//  RagsToRiches
//
//  Created by Carmelo I. Uria on 5/18/14.
//  Copyright (c) 2014 Carmelo Uria Corporation. All rights reserved.
//

#import "ViewController.h"

#import <MapKit/MapKit.h>

@interface ViewController () <MKMapViewDelegate>

@property (weak, nonatomic) IBOutlet MKMapView *mapView;

@end

@implementation ViewController

- (void) viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    
    MKLocalSearchRequest *searchRequest = [[MKLocalSearchRequest alloc] init];
    [searchRequest setNaturalLanguageQuery:@"Albertson's"];
    
    MKCoordinateRegion region;
    region.center.latitude = 43.6187100;
    region.center.longitude = -116.2146070;
    [searchRequest setRegion:region];
    
    // Create the local search to perform the search
    MKLocalSearch *localSearch = [[MKLocalSearch alloc] initWithRequest:searchRequest];
    [localSearch startWithCompletionHandler:^(MKLocalSearchResponse *response, NSError *error) {
        if (!error)
        {
            for (MKMapItem *mapItem in [response mapItems])
            {
                NSLog(@"Name: %@, Placemark title: %@", [mapItem name], [[mapItem placemark] title]);
                [[self mapView] addAnnotation:[mapItem placemark]];
            }
        }
        else
        {
            NSLog(@"Search Request Error: %@", [error localizedDescription]);
        }
    }];
}

- (void) didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
