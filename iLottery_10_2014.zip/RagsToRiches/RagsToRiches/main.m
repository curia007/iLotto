//
//  main.m
//  RagsToRiches
//
//  Created by Carmelo I. Uria on 5/18/14.
//  Copyright (c) 2014 Carmelo Uria Corporation. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "AppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
